"use strict";
(() => {
  // src/content/extractor.ts
  function escapeXmlEntities(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
  }
  function extractCleanBodyText(doc) {
    const body = doc.body;
    if (!body) {
      return "";
    }
    const clone = body.cloneNode(true);
    const tagsToRemove = [
      "script",
      "style",
      "noscript",
      "iframe",
      "object",
      "embed",
      "svg",
      "canvas",
      "nav",
      "footer"
    ];
    for (const tag of tagsToRemove) {
      const elements = clone.querySelectorAll(tag);
      elements.forEach((el) => el.remove());
    }
    const hiddenElements = clone.querySelectorAll('[hidden], [aria-hidden="true"]');
    hiddenElements.forEach((el) => el.remove());
    const rawText = clone.innerText ?? clone.textContent ?? "";
    return rawText.split("\n").map((line) => line.trim()).filter((line) => line.length > 0).join("\n");
  }
  function extractJsonLd(doc) {
    const scripts = doc.querySelectorAll('script[type="application/ld+json"]');
    const results = [];
    scripts.forEach((script) => {
      const content = script.textContent?.trim();
      if (!content) {
        return;
      }
      try {
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) {
          for (const item of parsed) {
            if (item && typeof item === "object") {
              results.push(item);
            }
          }
        } else if (parsed && typeof parsed === "object") {
          results.push(parsed);
        }
      } catch {
      }
    });
    return results;
  }
  function extractPageData(doc = document, locationHref = typeof window !== "undefined" ? window.location.href : "") {
    const url = locationHref;
    const title = doc.title || "";
    const getMeta = (selector) => {
      const el = doc.querySelector(`meta[${selector}]`);
      return el?.getAttribute("content")?.trim() || void 0;
    };
    const metaDescription = getMeta('name="description"') || getMeta('property="og:description"') || getMeta('name="twitter:description"');
    const rawKeywords = getMeta('name="keywords"');
    const metaKeywords = rawKeywords ? rawKeywords.split(",").map((k) => k.trim()).filter((k) => k.length > 0) : void 0;
    const canonicalLink = doc.querySelector('link[rel="canonical"]');
    const canonicalUrl = canonicalLink?.getAttribute("href")?.trim() || void 0;
    const ogTitle = getMeta('property="og:title"');
    const ogSiteName = getMeta('property="og:site_name"');
    const h1Elements = Array.from(doc.querySelectorAll("h1"));
    const h1 = h1Elements.map((el) => el.textContent?.trim() || "").filter((text) => text.length > 0);
    const subHeadings = Array.from(doc.querySelectorAll("h2, h3"));
    const headings = subHeadings.map((el) => el.textContent?.trim() || "").filter((text) => text.length > 0);
    let selectedText;
    if (typeof window !== "undefined" && window.getSelection) {
      const selection = window.getSelection()?.toString().trim();
      if (selection && selection.length > 0) {
        selectedText = selection;
      }
    }
    const cleanBodyText = extractCleanBodyText(doc);
    const jsonLd = extractJsonLd(doc);
    const sanitizedXml = [
      "<untrusted_job_content>",
      `  <source_url>${escapeXmlEntities(url)}</source_url>`,
      `  <page_title>${escapeXmlEntities(title)}</page_title>`,
      metaDescription ? `  <meta_description>${escapeXmlEntities(metaDescription)}</meta_description>` : "",
      h1.length > 0 ? `  <primary_headings>${h1.map((h) => escapeXmlEntities(h)).join(" | ")}</primary_headings>` : "",
      headings.length > 0 ? `  <section_headings>${headings.map((h) => escapeXmlEntities(h)).join(" | ")}</section_headings>` : "",
      selectedText ? `  <user_selected_text>${escapeXmlEntities(selectedText)}</user_selected_text>` : "",
      `  <body_content>
${escapeXmlEntities(cleanBodyText)}
  </body_content>`,
      "</untrusted_job_content>"
    ].filter(Boolean).join("\n");
    return {
      url,
      title,
      metaDescription,
      metaKeywords,
      canonicalUrl,
      ogTitle,
      ogSiteName,
      h1,
      headings,
      selectedText,
      cleanBodyText,
      sanitizedXml,
      jsonLd,
      extractedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }

  // ../../packages/domain/dist/types/ids.js
  function generateUUID() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0;
      const v = c === "x" ? r : r & 3 | 8;
      return v.toString(16);
    });
  }
  function sanitizeOrGenerateId(prefix, id) {
    if (id && id.trim().length > 0) {
      return id.trim();
    }
    return `${prefix}_${generateUUID()}`;
  }
  function createJobPostingId(id) {
    return sanitizeOrGenerateId("job", id);
  }
  function createRequirementId(id) {
    return sanitizeOrGenerateId("req", id);
  }
  function createFieldId(id) {
    return sanitizeOrGenerateId("fld", id);
  }

  // ../../packages/domain/dist/evidence/parser.js
  var COMMON_TECH_TERMS = [
    "TypeScript",
    "JavaScript",
    "Python",
    "Go",
    "Golang",
    "Rust",
    "Java",
    "C\\+\\+",
    "C#",
    "React",
    "Next\\.js",
    "Vue",
    "Angular",
    "Node\\.js",
    "Express",
    "NestJS",
    "GraphQL",
    "REST",
    "PostgreSQL",
    "Postgres",
    "MySQL",
    "MongoDB",
    "Redis",
    "Cassandra",
    "SQLite",
    "AWS",
    "Azure",
    "GCP",
    "Docker",
    "Kubernetes",
    "Terraform",
    "CI/CD",
    "Git",
    "Kafka",
    "RabbitMQ",
    "Tailwind",
    "Vite",
    "Webpack",
    "Vitest",
    "Jest"
  ];
  var TECH_REGEX = new RegExp(`\\b(${COMMON_TECH_TERMS.join("|")})\\b`, "gi");

  // ../../packages/domain/dist/job/synonyms.js
  var SYNONYM_GROUPS = [
    // Languages & Runtimes
    ["typescript", "ts"],
    ["javascript", "js", "ecmascript"],
    ["python", "py", "python3"],
    ["golang", "go"],
    ["csharp", "c#", ".net", "dotnet"],
    ["cpp", "c++"],
    ["rust", "rustlang"],
    ["ruby", "rails", "ruby on rails"],
    ["java"],
    ["php"],
    ["swift"],
    ["kotlin"],
    // Frontend Frameworks & Libraries
    ["react", "reactjs", "react.js"],
    ["nextjs", "next.js"],
    ["vue", "vuejs", "vue.js"],
    ["angular", "angularjs", "angular.js"],
    ["svelte", "sveltekit"],
    ["tailwind", "tailwindcss"],
    ["html", "html5"],
    ["css", "css3"],
    // Backend & APIs
    ["node", "nodejs", "node.js"],
    ["express", "expressjs", "express.js"],
    ["graphql", "gql"],
    ["rest", "restful", "rest api", "restful api", "restful apis"],
    ["grpc", "protobuf"],
    // Databases & Caches
    ["postgresql", "postgres"],
    ["mongodb", "mongo"],
    ["mysql"],
    ["redis"],
    ["elasticsearch", "elastic search", "es"],
    ["sql"],
    ["nosql"],
    // Cloud & DevOps
    ["kubernetes", "k8s"],
    ["docker", "containerization", "containers"],
    ["aws", "amazon web services"],
    ["gcp", "google cloud", "google cloud platform"],
    ["azure", "microsoft azure"],
    ["terraform", "iac", "infrastructure as code"],
    ["cicd", "ci/cd", "continuous integration", "continuous deployment"],
    // Architecture, Systems & Engineering Practices
    ["microservices", "distributed systems", "distributed architecture"],
    ["p2p", "peer to peer", "peer-to-peer", "decentralized", "p2p technologies", "distributed systems"],
    ["npm", "npm packages", "npm modules", "reusable modules", "modular code", "package management"],
    ["networking", "network protocols", "tcp", "udp", "websockets", "websocket", "low latency", "throughput", "advanced networking"],
    ["testing", "debugging", "unit testing", "test automation", "load testing", "benchmarking", "tdd", "test driven development"],
    ["oss", "open source", "open-source", "oss contributions", "open source software"],
    ["agile", "scrum"]
  ];
  var ALIAS_TO_CLUSTER = /* @__PURE__ */ new Map();
  for (const group of SYNONYM_GROUPS) {
    const normalizedGroup = group.map((item) => normalizeCompetencyToken(item));
    const clusterSet = new Set(normalizedGroup);
    for (const item of normalizedGroup) {
      ALIAS_TO_CLUSTER.set(item, clusterSet);
    }
  }
  function normalizeCompetencyToken(text) {
    if (!text)
      return "";
    return text.toLowerCase().trim().replace(/[/\\_-]+/g, " ").replace(/[^a-z0-9.+ #]/g, "").replace(/\s+/g, " ").trim();
  }

  // ../../packages/domain/dist/form/canonical-fields.js
  var AUTOCOMPLETE_MAP = {
    "given-name": { key: "first_name", path: "identity.legalFirstName" },
    "family-name": { key: "last_name", path: "identity.legalLastName" },
    name: { key: "full_name", path: "identity.fullName" },
    email: { key: "email", path: "identity.email" },
    tel: { key: "phone", path: "identity.phone" },
    "tel-national": { key: "phone", path: "identity.phone" },
    "address-line1": { key: "location_address", path: "identity.address" },
    "street-address": { key: "location_address", path: "identity.address" },
    "address-level2": { key: "location_city", path: "identity.city" },
    "postal-code": { key: "postal_code", path: "identity.postalCode" },
    country: { key: "country", path: "identity.country" },
    "country-name": { key: "country", path: "identity.country" }
  };
  var CLASSIFICATION_RULES = [
    {
      key: "first_name",
      path: "identity.legalFirstName",
      patterns: [
        /\bfirst[\s_-]*name\b/i,
        /\bgiven[\s_-]*name\b/i,
        /\bfname\b/i,
        /\bprenom\b/i,
        /\bnombre\b/i
      ],
      baseConfidence: 0.95
    },
    {
      key: "last_name",
      path: "identity.legalLastName",
      patterns: [
        /\blast[\s_-]*name\b/i,
        /\bfamily[\s_-]*name\b/i,
        /\bsurname\b/i,
        /\blname\b/i,
        /\bnom\b/i,
        /\bapellidos?\b/i
      ],
      baseConfidence: 0.95
    },
    {
      key: "full_name",
      path: "identity.fullName",
      patterns: [
        /\b(?:legal\s+)?full[\s_-]*name\b/i,
        /\bcandidate[\s_-]*name\b/i,
        /\byour[\s_-]*name\b/i,
        /\bapplicant[\s_-]*name\b/i
      ],
      baseConfidence: 0.92
    },
    {
      key: "email",
      path: "identity.email",
      patterns: [/\be[\s_-]?mail(?:\s*address)?\b/i, /\bcourriel\b/i, /\bcorreo\b/i],
      baseConfidence: 0.96
    },
    {
      key: "phone",
      path: "identity.phone",
      patterns: [
        /\bphone(?:\s*number)?\b/i,
        /\bmobile(?:\s*number)?\b/i,
        /\bcell(?:\s*phone)?\b/i,
        /\btelephone\b/i,
        /\bcontact[\s_-]*number\b/i
      ],
      baseConfidence: 0.94
    },
    {
      key: "resume",
      path: "documents.resume",
      patterns: [
        /\bresume\b/i,
        /\bcv\b/i,
        /\bcurriculum[\s_-]*vitae\b/i,
        /\battach[\s_-]*resume\b/i,
        /\bupload[\s_-]*resume\b/i
      ],
      baseConfidence: 0.97
    },
    {
      key: "cover_letter",
      path: "documents.coverLetter",
      patterns: [
        /\bcover[\s_-]*letter\b/i,
        /\bletter[\s_-]*of[\s_-]*motivation\b/i,
        /\bpersonal[\s_-]*statement\b/i
      ],
      baseConfidence: 0.95
    },
    {
      key: "linkedin_url",
      path: "links.linkedin",
      patterns: [/\blinked[\s_-]?in\b/i, /\blinkedin[\s_-]*profile\b/i, /\blinkedin[\s_-]*url\b/i],
      baseConfidence: 0.96
    },
    {
      key: "github_url",
      path: "links.github",
      patterns: [
        /\bgit[\s_-]?hub\b/i,
        /\bgithub[\s_-]*profile\b/i,
        /\bgithub[\s_-]*url\b/i,
        /\buseful[\s_-]*links?\b/i
      ],
      baseConfidence: 0.96
    },
    {
      key: "portfolio_url",
      path: "links.portfolio",
      patterns: [
        /\bportfolio\b/i,
        /\bpersonal[\s_-]*web(?:site)?\b/i,
        /\bweb(?:site)?[\s_-]*url\b/i,
        /\bblog[\s_-]*url\b/i
      ],
      baseConfidence: 0.9
    },
    {
      key: "location_city",
      path: "identity.city",
      patterns: [/\bcity\b/i, /\btown\b/i, /\blocation[\s_-]*city\b/i],
      baseConfidence: 0.88
    },
    {
      key: "location_address",
      path: "identity.address",
      patterns: [
        /\baddress\b/i,
        /\bstreet(?:\s*address)?\b/i,
        /\bline[\s_-]*1\b/i,
        /\bresidence\b/i
      ],
      baseConfidence: 0.88
    },
    {
      key: "postal_code",
      path: "identity.postalCode",
      patterns: [/\bzip(?:\s*code)?\b/i, /\bpostal(?:\s*code)?\b/i, /\bpostcode\b/i],
      baseConfidence: 0.92
    },
    {
      key: "country",
      path: "identity.country",
      patterns: [
        /\bcountry\b/i,
        /\bnation\b/i,
        /\bcountry[\s_-]*region\b/i,
        /\bfrom\s+which\s+country\b/i,
        /\bcountry\s+will\s+you\s+be\s+working\b/i
      ],
      baseConfidence: 0.92
    },
    {
      key: "work_authorization",
      path: "identity.workAuthorizations",
      patterns: [
        /\b(?:legally\s+)?authorized\s+to\s+work\b/i,
        /\bwork\s+authorization\b/i,
        /\bright\s+to\s+work\b/i,
        /\beligib(?:le|ility)\s+to\s+work\b/i,
        /\blawfully\s+authorized\b/i
      ],
      baseConfidence: 0.92
    },
    {
      key: "visa_sponsorship",
      path: "identity.requiresSponsorship",
      patterns: [
        /\b(?:require|need)\s+(?:visa\s+)?sponsorship\b/i,
        /\bvisa\s+sponsorship\b/i,
        /\bsponsor(?:ship)?(?:\s+now\s+or\s+in\s+the\s+future)?\b/i,
        /\bh[\s_-]?1b\b/i
      ],
      baseConfidence: 0.92
    },
    {
      key: "salary_expectation",
      path: "professional.targetSalary",
      patterns: [
        /\bdesired\s+(?:annual\s+)?(?:salary|compensation|pay)\b/i,
        /\bexpected\s+(?:annual\s+)?(?:salary|compensation|pay)\b/i,
        /\bannual\s+(?:salary|compensation|pay)\b/i,
        /\bsalary\s+(?:expectation|requirement)s?\b/i,
        /\bcompensation\s+expectation\b/i,
        /\bhourly\s+rate\b/i
      ],
      baseConfidence: 0.92
    },
    {
      key: "referral_source",
      path: "professional.referralSource",
      patterns: [
        /\bhow\s+did\s+you\s+hear\b/i,
        /\bhow\s+did\s+you\s+find\b/i,
        /\breferral\s+source\b/i,
        /\bwhere\s+did\s+you\s+hear\b/i
      ],
      baseConfidence: 0.9
    },
    {
      key: "earliest_start_date",
      path: "professional.earliestStartDate",
      patterns: [
        /\b(?:earliest\s+)?start\s*date\b/i,
        /\bavailable\s+to\s+start\b/i,
        /\bnotice\s+period\b/i,
        /\bavailability\b/i
      ],
      baseConfidence: 0.88
    },
    {
      key: "eeo_gender",
      path: "identity.eeo.gender",
      patterns: [/\bgender(?:\s*identity)?\b/i, /\bsex\b/i],
      baseConfidence: 0.93
    },
    {
      key: "eeo_race",
      path: "identity.eeo.race",
      patterns: [/\brace\b/i, /\bethnicity\b/i, /\brace\s*\/\s*ethnicity\b/i],
      baseConfidence: 0.93
    },
    {
      key: "eeo_veteran",
      path: "identity.eeo.veteranStatus",
      patterns: [/\bveteran(?:\s*status)?\b/i, /\bmilitary\s+service\b/i, /\bprotected\s+veteran\b/i],
      baseConfidence: 0.93
    },
    {
      key: "eeo_disability",
      path: "identity.eeo.disabilityStatus",
      patterns: [/\bdisability(?:\s*status)?\b/i, /\bphysical\s+or\s+mental\s+impairment\b/i],
      baseConfidence: 0.93
    }
  ];
  function classifyFormField(attrs) {
    if (attrs.autocomplete && attrs.autocomplete !== "off" && attrs.autocomplete !== "on") {
      const cleanTokens = attrs.autocomplete.toLowerCase().trim().split(/\s+/);
      for (const token of cleanTokens) {
        const match = AUTOCOMPLETE_MAP[token];
        if (match) {
          return {
            canonicalKey: match.key,
            confidence: 0.98,
            inferredProfilePath: match.path,
            rationale: `Matched HTML autocomplete token: '${token}'`
          };
        }
      }
    }
    if (attrs.type === "email") {
      return {
        canonicalKey: "email",
        confidence: 0.97,
        inferredProfilePath: "identity.email",
        rationale: `Matched native input type='email'`
      };
    }
    if (attrs.type === "tel") {
      return {
        canonicalKey: "phone",
        confidence: 0.95,
        inferredProfilePath: "identity.phone",
        rationale: `Matched native input type='tel'`
      };
    }
    const labelText = (attrs.label || attrs.ariaLabel || "").trim();
    const nameText = `${attrs.name || ""} ${attrs.id || ""} ${attrs.dataAutomationId || ""}`.replace(/[\[\]_.-]+/g, " ").replace(/\s+/g, " ").trim();
    const placeholderText = (attrs.placeholder || "").trim();
    if (labelText) {
      for (const rule of CLASSIFICATION_RULES) {
        for (const pattern of rule.patterns) {
          if (pattern.test(labelText)) {
            return {
              canonicalKey: rule.key,
              confidence: rule.baseConfidence,
              inferredProfilePath: rule.path,
              rationale: `Matched label text pattern '${pattern}' on label '${labelText}'`
            };
          }
        }
      }
    }
    if (nameText) {
      for (const rule of CLASSIFICATION_RULES) {
        for (const pattern of rule.patterns) {
          if (pattern.test(nameText)) {
            return {
              canonicalKey: rule.key,
              confidence: Math.max(0.7, Number((rule.baseConfidence - 0.15).toFixed(2))),
              inferredProfilePath: rule.path,
              rationale: `Matched name/id attribute pattern '${pattern}' on '${nameText}'`
            };
          }
        }
      }
    }
    if (placeholderText) {
      for (const rule of CLASSIFICATION_RULES) {
        for (const pattern of rule.patterns) {
          if (pattern.test(placeholderText)) {
            return {
              canonicalKey: rule.key,
              confidence: Math.max(0.6, Number((rule.baseConfidence - 0.2).toFixed(2))),
              inferredProfilePath: rule.path,
              rationale: `Matched placeholder text pattern '${pattern}' on '${placeholderText}'`
            };
          }
        }
      }
    }
    return {
      canonicalKey: "custom_question",
      confidence: 0.3,
      rationale: "No canonical pattern matched; classified as custom application question."
    };
  }
  function isHoneypotField(attrs, style) {
    const cleanIdentifier = `${attrs.name || ""} ${attrs.id || ""}`.toLowerCase().replace(/[-_]+/g, " ");
    if (/\bhoneypot\b/.test(cleanIdentifier) || /\bhidden field\b/.test(cleanIdentifier) || /\banti\s*spam\b/.test(cleanIdentifier) || /\btrap\b/.test(cleanIdentifier) || /\bwebsite hp\b/.test(cleanIdentifier)) {
      return true;
    }
    if (style) {
      if (style.display === "none" || style.visibility === "hidden") {
        return true;
      }
      if (style.opacity === "0" || style.opacity === "0.0") {
        return true;
      }
      if (style.width !== void 0 && style.width <= 1 && style.height !== void 0 && style.height <= 1) {
        return true;
      }
      if (style.left !== void 0 && style.left < -500) {
        return true;
      }
      if (style.top !== void 0 && style.top < -500) {
        return true;
      }
    }
    return false;
  }

  // ../../packages/domain/dist/form/browser-action.js
  var SUBMIT_PATTERNS = [
    /submit/i,
    /apply\s*now/i,
    /send\s*application/i,
    /finish\s*application/i,
    /complete\s*application/i,
    /button\[type=["']?submit["']?\]/i,
    /input\[type=["']?submit["']?\]/i
  ];
  function isSubmissionIntent(selector, description) {
    for (const pattern of SUBMIT_PATTERNS) {
      if (pattern.test(selector) || description && pattern.test(description)) {
        return true;
      }
    }
    return false;
  }
  function validateBrowserActionSafety(action) {
    if (action.actionType === "click" && isSubmissionIntent(action.selector, action.description)) {
      return {
        isProhibited: true,
        reason: "Automated submission is strictly prohibited. The candidate must submit manually."
      };
    }
    if (action.value && action.value.toLowerCase().startsWith("javascript:")) {
      return {
        isProhibited: true,
        reason: "Execution of javascript: pseudo-protocol is strictly prohibited."
      };
    }
    if (/<script|eval\(|alert\(/i.test(action.selector)) {
      return {
        isProhibited: true,
        reason: "Selector contains disallowed script execution tokens."
      };
    }
    return {
      isProhibited: false
    };
  }

  // ../../packages/domain/dist/ai/writing-style.js
  var DEFAULT_WRITING_STYLE = {
    id: "default",
    sentenceLength: "medium",
    technicalDetail: "moderate",
    preferredVocabulary: [],
    avoidedVocabulary: [],
    formality: "conversational",
    confidence: "direct",
    answerLengthPreference: "normal",
    personalPhrases: [],
    engineeringDescriptions: [],
    sampleCount: 0,
    lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };

  // src/content/normalizer.ts
  function extractStructuredSections(container) {
    const responsibilities = [];
    const requirements = [];
    const headingSelector = "h1, h2, h3, h4, h5, h6, .section-title, p > strong, p > b";
    const headings = Array.from(container.querySelectorAll(headingSelector));
    if (headings.length === 0) {
      const rawItems = extractListItems(container);
      return {
        responsibilities: [],
        requirements: normalizeRequirementsList(rawItems, "required")
      };
    }
    const processedLists = /* @__PURE__ */ new Set();
    for (const heading of headings) {
      const headingText = heading.textContent?.trim() || "";
      if (!headingText) continue;
      let sectionType = "ignore";
      if (/\b(nice\s+to\s+have|preferred|bonus|plus|desirable|optional)\b/i.test(headingText)) {
        sectionType = "preferred";
      } else if (/\b(responsibilit\w*|duties|what\s+you('ll|\s+will)\s+do|the\s+role|about\s+the\s+role)\b/i.test(headingText)) {
        sectionType = "responsibilities";
      } else if (/\b(requirement\w*|qualification\w*|what\s+you\s+(bring|need)|must\s+have|who\s+you\s+are|basic\s+qualification\w*)\b/i.test(headingText)) {
        sectionType = "required";
      }
      if (sectionType === "ignore") {
        continue;
      }
      const sectionItems = [];
      const sectionWrapper = heading.closest(".section-wrapper");
      if (sectionWrapper && sectionWrapper !== container) {
        const lists = sectionWrapper.querySelectorAll("ul, ol");
        lists.forEach((listEl) => {
          if (!processedLists.has(listEl)) {
            processedLists.add(listEl);
            sectionItems.push(...extractListItems(listEl));
          }
        });
      }
      if (sectionItems.length === 0) {
        let current = heading.nextElementSibling;
        if (!current && heading.parentElement && heading.parentElement !== container) {
          current = heading.parentElement.nextElementSibling;
        }
        while (current) {
          if (current.matches(headingSelector) || current.querySelector(headingSelector)) {
            break;
          }
          const tag = current.tagName.toUpperCase();
          if (tag === "UL" || tag === "OL") {
            if (!processedLists.has(current)) {
              processedLists.add(current);
              sectionItems.push(...extractListItems(current));
            }
          } else if (tag === "P") {
            const text = current.textContent?.trim();
            if (text && text.length >= 15 && text.length <= 260 && !current.querySelector(headingSelector)) {
              sectionItems.push(text);
            }
          } else {
            const nestedLists = current.querySelectorAll("ul, ol");
            nestedLists.forEach((list) => {
              if (!processedLists.has(list)) {
                processedLists.add(list);
                sectionItems.push(...extractListItems(list));
              }
            });
          }
          current = current.nextElementSibling;
        }
      }
      if (sectionItems.length > 0) {
        if (sectionType === "responsibilities") {
          responsibilities.push(...sectionItems);
        } else if (sectionType === "preferred") {
          requirements.push(...normalizeRequirementsList(sectionItems, "preferred"));
        } else if (sectionType === "required") {
          requirements.push(...normalizeRequirementsList(sectionItems, "required"));
        }
      }
    }
    const allLists = Array.from(container.querySelectorAll("ul, ol"));
    const uncapturedItems = [];
    for (const listEl of allLists) {
      if (!processedLists.has(listEl)) {
        processedLists.add(listEl);
        uncapturedItems.push(...extractListItems(listEl));
      }
    }
    if (uncapturedItems.length > 0) {
      requirements.unshift(...normalizeRequirementsList(uncapturedItems, "required"));
    }
    const distinctText = /* @__PURE__ */ new Set([
      ...requirements.map((r) => r.rawText),
      ...responsibilities
    ]);
    const requirementParagraphRegex = /\b(proven experience|experience (with|in|using|building|developing|managing|creating)|familiarity with|knowledge of|ability to|contributions? to|strong (competency|skillset)|hands-on|proficiency in)\b/i;
    const containerParagraphs = Array.from(container.querySelectorAll("p"));
    const paragraphItems = [];
    for (const p of containerParagraphs) {
      if (p.closest("ul, ol, li, h1, h2, h3, h4, h5, h6")) continue;
      const text = p.textContent?.trim();
      if (!text || text.length < 15 || text.length > 260) continue;
      if (distinctText.has(text)) continue;
      if (/^(we are|at \w+, we|join .* and|why join|about us|our (team|company)|we('re| are) (looking|seeking)|we're seeking|is responsible for)/i.test(text)) {
        continue;
      }
      if (!requirementParagraphRegex.test(text)) continue;
      paragraphItems.push(text);
      distinctText.add(text);
    }
    if (paragraphItems.length > 0) {
      requirements.push(...normalizeRequirementsList(paragraphItems, "required"));
    }
    if (requirements.length === 0) {
      const rawItems = extractListItems(container);
      return {
        responsibilities,
        requirements: normalizeRequirementsList(rawItems, "required")
      };
    }
    return { responsibilities, requirements };
  }
  function extractListItems(container) {
    if (typeof container === "string") {
      return container.split("\n").map((line) => line.replace(/^[-*•\d.)\s]+/, "").trim()).filter((line) => line.length > 5);
    }
    const items = [];
    const listElements = container.querySelectorAll("li");
    if (listElements.length > 0) {
      listElements.forEach((el) => {
        const text = el.textContent?.trim();
        if (text && text.length > 0) {
          items.push(text);
        }
      });
      return items;
    }
    const paragraphs = container.querySelectorAll("p");
    paragraphs.forEach((p) => {
      const text = p.textContent?.trim();
      if (text && text.length > 5) {
        items.push(text);
      }
    });
    return items;
  }
  function classifyRequirementCategory(text) {
    const lower = text.toLowerCase();
    if (/(\d+)\+?\s*years?|\byears\s+of\s+experience\b/i.test(lower)) {
      return "experience_level";
    }
    if (/\b(bachelor|master|phd|degree|b\.s\.|m\.s\.|diploma)\b/i.test(lower)) {
      return "education_credential";
    }
    if (/\b(authorized|authorization|sponsorship|visa|work permit|clearance|citizen)\b/i.test(lower)) {
      return "legal_authorization";
    }
    if (/\b(certified|certification|aws certified|cka|cissp|pmp)\b/i.test(lower)) {
      return "certification";
    }
    if (/\b(communication|verbal|written|collaborat\w*|mentor\w*|leadership|leader\w*|interpersonal|team\s*player)\b/i.test(lower)) {
      return "soft_skill";
    }
    if (/\b(hipaa|fintech|banking|bank\w*|payment\w*|swift|iso\s*20022|healthcare|compliance|pci-dss|gdpr|fda|clinical)\b/i.test(lower)) {
      return "domain_knowledge";
    }
    return "technical_skill";
  }
  function extractYearsRequired(text) {
    const match = text.match(/(\d+)\+?\s*years?/i);
    if (match && match[1]) {
      const years = parseInt(match[1], 10);
      return isNaN(years) ? void 0 : years;
    }
    return void 0;
  }
  function extractCompetencyKey(text) {
    let cleaned = text.trim();
    const prefixes = [
      /^\d+\+?\s*years?\s+(of\s+)?(professional\s+)?(software\s+)?experience\s+(in|with|building|developing|designing|engineering)?\s*/i,
      /^at\s+least\s+\d+\s+years\s+(of\s+)?(experience\s+(in|with|building|developing)?)?\s*/i,
      /^minimum\s+\d+\s+years\s+(of\s+)?(experience\s+(in|with|building|developing)?)?\s*/i,
      /^(strong\s+proficiency\s+with|proficiency\s+in|hands-on\s+experience\s+with|experience\s+(with|in|creating(\s+and\s+managing)?|building|developing|designing|architecting|using|deploying|working\s+with)?|familiarity\s+with|knowledge\s+of)\s*/i,
      /^(must\s+have|ability\s+to|demonstrated\s+experience\s+in|proven\s+track\s+record\s+in)\s*/i,
      /^(strong\s+competency\s+in|solid\s+skillset\s+in|deep\s+understanding\s+of|strong\s+understanding\s+of)\s*(writing|building|developing)?\s*/i
    ];
    let changed = true;
    while (changed) {
      changed = false;
      for (const prefix of prefixes) {
        if (prefix.test(cleaned)) {
          cleaned = cleaned.replace(prefix, "").trim();
          changed = true;
        }
      }
    }
    cleaned = cleaned.replace(/[.:;]+$/, "").trim();
    cleaned = cleaned.replace(/\s*\(\d+\/\d+\)\s*/g, " ").trim();
    const withMatch = cleaned.match(/^([^,;]+?)\s+(?:with|including)\s+/i);
    if (withMatch && withMatch[1] && withMatch[1].trim().length > 1) {
      cleaned = withMatch[1].trim();
    }
    const clauses = cleaned.split(/[,;]|\band\b/i);
    let primary = clauses[0]?.trim();
    if (primary && /^(modular|scalable|clean|robust|modern)$/i.test(primary) && clauses[1]) {
      primary = `${primary}, ${clauses[1].trim()}`;
    }
    return primary && primary.length > 0 ? primary : text.slice(0, 50).trim();
  }
  function normalizeRequirementsList(rawItems, defaultImportance = "required") {
    return rawItems.map((rawText) => {
      const category = classifyRequirementCategory(rawText);
      const yearsRequired = extractYearsRequired(rawText);
      const normalizedSkillOrCompetency = extractCompetencyKey(rawText);
      let importance = defaultImportance;
      const lower = rawText.toLowerCase();
      if (/\b(nice\s+to\s+have|bonus|preferred|plus|advantage)\b/i.test(lower)) {
        importance = "preferred";
      } else if (/\b(strongly\s+preferred|highly\s+desired)\b/i.test(lower)) {
        importance = "strongly_preferred";
      } else if (/\b(must\s+have|required|mandatory|essential)\b/i.test(lower)) {
        importance = "required";
      }
      const isRequired = importance === "required" || importance === "strongly_preferred";
      return {
        id: createRequirementId(),
        rawText,
        normalizedSkillOrCompetency,
        category,
        importance,
        ...yearsRequired !== void 0 ? { yearsRequired } : {},
        isRequired,
        matchedEvidenceIds: []
      };
    });
  }

  // src/content/adapters/jsonld-adapter.ts
  var JsonLdJobSiteAdapter = class {
    id = "jsonld";
    name = "Schema.org JSON-LD Adapter";
    priority = 100;
    matches(_url, doc) {
      const records = extractJsonLd(doc);
      return records.some((r) => r["@type"] === "JobPosting");
    }
    extract(doc, url) {
      const records = extractJsonLd(doc);
      const data = records.find((r) => r["@type"] === "JobPosting") || {};
      const title = typeof data["title"] === "string" ? data["title"].trim() : doc.title.trim();
      let companyName = "Unknown Company";
      if (data["hiringOrganization"] && typeof data["hiringOrganization"] === "object") {
        const org = data["hiringOrganization"];
        if (typeof org["name"] === "string" && org["name"].trim().length > 0) {
          companyName = org["name"].trim();
        }
      }
      let location = "Remote / Unspecified";
      const rawLocations = data["jobLocation"];
      if (Array.isArray(rawLocations)) {
        const placeNames = [];
        for (const loc of rawLocations) {
          if (typeof loc !== "object" || loc === null) continue;
          const locObj = loc;
          if (locObj["@type"] === "VirtualLocation") {
            placeNames.push(String(locObj["description"] || "Remote"));
            continue;
          }
          if (locObj["address"] && typeof locObj["address"] === "object") {
            const addr = locObj["address"];
            const parts = [addr.addressLocality, addr.addressRegion, addr.addressCountry].filter(Boolean);
            if (parts.length > 0) {
              placeNames.push(parts.join(", "));
            }
          }
        }
        if (placeNames.length > 0) {
          location = placeNames.join("; ");
        }
      } else if (rawLocations && typeof rawLocations === "object") {
        const loc = rawLocations;
        if (loc["@type"] === "VirtualLocation") {
          location = String(loc["description"] || "Remote");
        } else if (loc["address"] && typeof loc["address"] === "object") {
          const addr = loc["address"];
          const parts = [addr.addressLocality, addr.addressRegion, addr.addressCountry].filter(Boolean);
          if (parts.length > 0) {
            location = parts.join(", ");
          }
        }
      }
      let workplaceType = "onsite";
      const locLower = location.toLowerCase();
      const rawDescLower = typeof data["description"] === "string" ? data["description"].toLowerCase() : "";
      if (locLower.includes("remote") || rawDescLower.includes("remote") || data["jobLocationType"] === "TELECOMMUTE") {
        workplaceType = "remote";
      } else if (locLower.includes("hybrid") || rawDescLower.includes("hybrid")) {
        workplaceType = "hybrid";
      }
      let employmentType = "full_time";
      const empTypeRaw = String(data["employmentType"] || "").toUpperCase();
      if (empTypeRaw.includes("PART_TIME")) {
        employmentType = "part_time";
      } else if (empTypeRaw.includes("CONTRACT") || empTypeRaw.includes("TEMPORARY")) {
        employmentType = "contract";
      } else if (empTypeRaw.includes("INTERN")) {
        employmentType = "internship";
      }
      let salaryRange;
      if (data["baseSalary"] && typeof data["baseSalary"] === "object") {
        const sal = data["baseSalary"];
        const val = sal["value"] || {};
        const min = Number(val["minValue"]);
        const max = Number(val["maxValue"] || min);
        if (!isNaN(min) && min > 0) {
          salaryRange = {
            min,
            max: isNaN(max) || max < min ? min : max,
            currency: String(sal["currency"] || "USD"),
            period: String(val["unitText"] || "").toUpperCase() === "HOUR" ? "hourly" : "annual"
          };
        }
      }
      const rawHtmlDesc = typeof data["description"] === "string" ? data["description"] : "";
      let requirements = [];
      if (rawHtmlDesc.length > 0) {
        const parsed = new DOMParser().parseFromString(rawHtmlDesc, "text/html");
        requirements = [...extractStructuredSections(parsed.body).requirements];
      }
      if (requirements.length === 0) {
        requirements = [...extractStructuredSections(doc.body).requirements];
      }
      return {
        id: createJobPostingId(),
        url: url.href,
        title,
        companyName,
        location,
        workplaceType,
        employmentType,
        ...salaryRange ? { salaryRange } : {},
        rawDescription: rawHtmlDesc.length > 0 ? rawHtmlDesc : extractCleanBodyText(doc),
        parsedAt: (/* @__PURE__ */ new Date()).toISOString(),
        requirements,
        metadata: {
          adapter: this.id,
          schemaType: "JobPosting"
        }
      };
    }
  };

  // src/content/adapters/greenhouse-adapter.ts
  var GreenhouseJobSiteAdapter = class {
    id = "greenhouse";
    name = "Greenhouse ATS Adapter";
    priority = 90;
    matches(url, doc) {
      const isHostMatch = url.hostname.includes("greenhouse.io");
      const hasGreenhouseDom = Boolean(
        doc.querySelector(".app-title") || doc.querySelector("#app_body") || doc.querySelector("#header .company-name") || doc.querySelector('[data-mapped="true"]')
      );
      return isHostMatch || hasGreenhouseDom;
    }
    extract(doc, url) {
      const titleEl = doc.querySelector(".app-title") || doc.querySelector("#header h1") || doc.querySelector("h1");
      const title = titleEl?.textContent?.trim() || doc.title.trim();
      const companyEl = doc.querySelector(".company-name") || doc.querySelector("#header .company-name");
      let companyName = companyEl?.textContent?.trim().replace(/^at\s+/i, "") || "";
      if (!companyName) {
        const titleMatch = doc.title.match(/\bat\s+([^|-]+)/i);
        companyName = titleMatch && titleMatch[1] ? titleMatch[1].trim() : "Unknown Company";
      }
      const locationEl = doc.querySelector(".location") || doc.querySelector("#header .location");
      const location = locationEl?.textContent?.trim() || "Remote / Unspecified";
      let workplaceType = "onsite";
      const locLower = location.toLowerCase();
      const cleanText = extractCleanBodyText(doc);
      if (locLower.includes("remote") || cleanText.toLowerCase().includes("remote")) {
        workplaceType = "remote";
      } else if (locLower.includes("hybrid") || cleanText.toLowerCase().includes("hybrid")) {
        workplaceType = "hybrid";
      }
      const contentEl = doc.querySelector("#content .body") || doc.querySelector("#content") || doc.body;
      const { requirements } = extractStructuredSections(contentEl);
      return {
        id: createJobPostingId(),
        url: url.href,
        title,
        companyName,
        location,
        workplaceType,
        employmentType: "full_time",
        rawDescription: cleanText,
        parsedAt: (/* @__PURE__ */ new Date()).toISOString(),
        requirements,
        metadata: {
          adapter: this.id,
          sourceAts: "Greenhouse"
        }
      };
    }
  };

  // src/content/adapters/lever-adapter.ts
  var LeverJobSiteAdapter = class {
    id = "lever";
    name = "Lever ATS Adapter";
    priority = 90;
    matches(url, doc) {
      const isHostMatch = url.hostname.includes("lever.co");
      const hasLeverDom = Boolean(
        doc.querySelector(".posting-headline") || doc.querySelector(".posting-categories") || doc.querySelector(".section.page-centered")
      );
      return isHostMatch || hasLeverDom;
    }
    extract(doc, url) {
      const titleEl = doc.querySelector(".posting-headline h2") || doc.querySelector(".posting-headline") || doc.querySelector("h1");
      const title = titleEl?.textContent?.trim() || doc.title.trim();
      let companyName = "Unknown Company";
      const pathParts = url.pathname.split("/").filter(Boolean);
      if (url.hostname.includes("lever.co") && pathParts.length > 0 && pathParts[0] && pathParts[0] !== "jobs") {
        companyName = pathParts[0].charAt(0).toUpperCase() + pathParts[0].slice(1);
      } else {
        const titleMatch = doc.title.match(/^([^|-]+)\s*[-|]/);
        if (titleMatch && titleMatch[1]) {
          companyName = titleMatch[1].trim();
        }
      }
      const locationEl = doc.querySelector(".sort-by-location") || doc.querySelector(".location");
      const location = locationEl?.textContent?.trim() || "Remote / Unspecified";
      const commitmentEl = doc.querySelector(".sort-by-commitment");
      const commitmentText = commitmentEl?.textContent?.toLowerCase() || "";
      let employmentType = "full_time";
      if (commitmentText.includes("part-time")) {
        employmentType = "part_time";
      } else if (commitmentText.includes("contract")) {
        employmentType = "contract";
      } else if (commitmentText.includes("intern")) {
        employmentType = "internship";
      }
      const workplaceEl = doc.querySelector(".workplaceTypes");
      const workplaceText = workplaceEl?.textContent?.toLowerCase() || "";
      let workplaceType = "onsite";
      const locLower = location.toLowerCase();
      const cleanText = extractCleanBodyText(doc);
      if (workplaceText.includes("remote") || locLower.includes("remote") || cleanText.toLowerCase().includes("remote")) {
        workplaceType = "remote";
      } else if (workplaceText.includes("hybrid") || locLower.includes("hybrid")) {
        workplaceType = "hybrid";
      }
      const contentEl = doc.querySelector(".section.page-centered .content") || doc.querySelector(".section.page-centered") || doc.body;
      const { requirements } = extractStructuredSections(contentEl);
      return {
        id: createJobPostingId(),
        url: url.href,
        title,
        companyName,
        location,
        workplaceType,
        employmentType,
        rawDescription: cleanText,
        parsedAt: (/* @__PURE__ */ new Date()).toISOString(),
        requirements,
        metadata: {
          adapter: this.id,
          sourceAts: "Lever"
        }
      };
    }
  };

  // src/content/adapters/workday-adapter.ts
  var WorkdayJobSiteAdapter = class {
    id = "workday";
    name = "Workday ATS Adapter";
    priority = 90;
    matches(url, doc) {
      const isHostMatch = url.hostname.includes("myworkdayjobs.com");
      const hasWorkdayDom = Boolean(
        doc.querySelector('[data-automation-id="jobPostingHeader"]') || doc.querySelector('[data-automation-id="jobPostingDescription"]')
      );
      return isHostMatch || hasWorkdayDom;
    }
    extract(doc, url) {
      const titleEl = doc.querySelector('[data-automation-id="jobPostingHeaderTitle"]') || doc.querySelector('[data-automation-id="jobPostingHeader"] h1') || doc.querySelector("h1");
      const title = titleEl?.textContent?.trim() || doc.title.trim();
      let companyName = "Unknown Company";
      const subdomains = url.hostname.split(".");
      if (subdomains.length > 2 && subdomains[0] && subdomains[0] !== "www" && subdomains[0] !== "myworkdayjobs") {
        const sub = subdomains[0];
        companyName = sub.charAt(0).toUpperCase() + sub.slice(1);
      }
      if (companyName === "Unknown Company") {
        const titleMatch = doc.title.match(/[-|]\s*([^|-]+)$/);
        if (titleMatch && titleMatch[1]) {
          companyName = titleMatch[1].trim();
        }
      }
      const locationEl = doc.querySelector('[data-automation-id="locations"]');
      const location = locationEl?.textContent?.trim() || "Remote / Unspecified";
      const timeTypeEl = doc.querySelector('[data-automation-id="timeType"]');
      const timeTypeText = timeTypeEl?.textContent?.toLowerCase() || "";
      let employmentType = "full_time";
      if (timeTypeText.includes("part time")) {
        employmentType = "part_time";
      } else if (timeTypeText.includes("contract")) {
        employmentType = "contract";
      }
      const cleanText = extractCleanBodyText(doc);
      let workplaceType = "onsite";
      if (location.toLowerCase().includes("remote") || cleanText.toLowerCase().includes("remote")) {
        workplaceType = "remote";
      } else if (location.toLowerCase().includes("hybrid") || cleanText.toLowerCase().includes("hybrid")) {
        workplaceType = "hybrid";
      }
      const descEl = doc.querySelector('[data-automation-id="jobPostingDescription"]') || doc.body;
      const { requirements } = extractStructuredSections(descEl);
      const jobIdEl = doc.querySelector('[data-automation-id="jobPostingId"]');
      const jobId = jobIdEl?.textContent?.trim() || "";
      return {
        id: createJobPostingId(),
        url: url.href,
        title,
        companyName,
        location,
        workplaceType,
        employmentType,
        rawDescription: cleanText,
        parsedAt: (/* @__PURE__ */ new Date()).toISOString(),
        requirements,
        metadata: {
          adapter: this.id,
          sourceAts: "Workday",
          ...jobId ? { workdayJobId: jobId } : {}
        }
      };
    }
  };

  // src/content/adapters/generic-adapter.ts
  var GenericJobSiteAdapter = class {
    id = "generic";
    name = "Generic Semantic Parser";
    priority = 10;
    matches(_url, _doc) {
      return true;
    }
    extract(doc, url) {
      const ogTitle = doc.querySelector('meta[property="og:title"]')?.getAttribute("content")?.trim();
      const h1 = doc.querySelector("h1")?.textContent?.trim();
      const title = h1 || ogTitle || doc.title.trim();
      const ogSiteName = doc.querySelector('meta[property="og:site_name"]')?.getAttribute("content")?.trim();
      let companyName = ogSiteName || "";
      if (!companyName) {
        const domainParts = url.hostname.replace(/^www\./, "").split(".");
        if (domainParts.length >= 2) {
          const candidate = domainParts[0] === "careers" || domainParts[0] === "jobs" ? domainParts[1] : domainParts[0];
          if (candidate) {
            companyName = candidate.charAt(0).toUpperCase() + candidate.slice(1);
          }
        }
      }
      if (!companyName) {
        companyName = "Company";
      }
      const cleanText = extractCleanBodyText(doc);
      let workplaceType = "onsite";
      if (cleanText.toLowerCase().includes("remote") || title.toLowerCase().includes("remote")) {
        workplaceType = "remote";
      } else if (cleanText.toLowerCase().includes("hybrid") || title.toLowerCase().includes("hybrid")) {
        workplaceType = "hybrid";
      }
      const contentContainer = doc.querySelector("article") || doc.querySelector('[class*="job-description"]') || doc.querySelector('[id*="job-description"]') || doc.querySelector('[class*="description"]') || doc.querySelector("main") || doc.body;
      const { requirements } = extractStructuredSections(contentContainer);
      return {
        id: createJobPostingId(),
        url: url.href,
        title,
        companyName,
        location: "Remote / Unspecified",
        workplaceType,
        employmentType: "full_time",
        rawDescription: cleanText,
        parsedAt: (/* @__PURE__ */ new Date()).toISOString(),
        requirements,
        metadata: {
          adapter: this.id,
          parsedBy: "GenericSemanticParser"
        }
      };
    }
  };

  // src/content/adapters/index.ts
  var REGISTERED_ADAPTERS = [
    new JsonLdJobSiteAdapter(),
    new GreenhouseJobSiteAdapter(),
    new LeverJobSiteAdapter(),
    new WorkdayJobSiteAdapter(),
    new GenericJobSiteAdapter()
  ];
  function findMatchingAdapter(url, doc) {
    const sorted = [...REGISTERED_ADAPTERS].sort((a, b) => b.priority - a.priority);
    for (const adapter of sorted) {
      if (adapter.matches(url, doc)) {
        return adapter;
      }
    }
    return new GenericJobSiteAdapter();
  }
  function extractStructuredJob(doc = document, urlString) {
    const resolvedUrl = urlString ?? (typeof window !== "undefined" ? window.location.href : void 0);
    if (!resolvedUrl) {
      throw new Error("Cannot extract a job posting without a document URL.");
    }
    let url;
    try {
      url = new URL(resolvedUrl);
    } catch {
      throw new Error(`Cannot extract a job posting: "${resolvedUrl}" is not a valid URL.`);
    }
    const adapter = findMatchingAdapter(url, doc);
    return adapter.extract(doc, url);
  }

  // src/content/adapters/form-crawler-helpers.ts
  function cleanLabelText(raw) {
    return raw.replace(/\s+/g, " ").replace(/[*:\t\r\n]+/g, "").trim();
  }
  function generateElementSelector(element, root) {
    if (element.id && /^[\w-]+$/.test(element.id)) {
      const matching = root.querySelectorAll(`#${CSS.escape(element.id)}`);
      if (matching.length === 1) {
        return `#${CSS.escape(element.id)}`;
      }
    }
    const testAttrs = ["data-testid", "data-automation-id", "data-qa", "data-cy"];
    for (const attr of testAttrs) {
      const val = element.getAttribute(attr);
      if (val) {
        const sel = `[${attr}="${CSS.escape(val)}"]`;
        if (root.querySelectorAll(sel).length === 1) {
          return sel;
        }
      }
    }
    const name = element.getAttribute("name");
    if (name) {
      const sel = `${element.tagName.toLowerCase()}[name="${CSS.escape(name)}"]`;
      if (root.querySelectorAll(sel).length === 1) {
        return sel;
      }
    }
    if (element.classList && element.classList.length > 0) {
      for (const cls of Array.from(element.classList)) {
        if (cls && !cls.startsWith("ng-") && !cls.startsWith("jsx-")) {
          const sel = `${element.tagName.toLowerCase()}.${CSS.escape(cls)}`;
          if (root.querySelectorAll(sel).length === 1) {
            return sel;
          }
        }
      }
    }
    const path = [];
    let curr = element;
    while (curr && curr !== root && curr !== document.body) {
      let selector = curr.tagName.toLowerCase();
      if (curr.id && /^[\w-]+$/.test(curr.id)) {
        selector = `#${CSS.escape(curr.id)}`;
        path.unshift(selector);
        break;
      } else {
        let siblingIndex = 1;
        let sibling = curr.previousElementSibling;
        while (sibling) {
          if (sibling.tagName === curr.tagName) {
            siblingIndex++;
          }
          sibling = sibling.previousElementSibling;
        }
        selector += `:nth-of-type(${siblingIndex})`;
      }
      path.unshift(selector);
      curr = curr.parentElement;
    }
    return path.join(" > ") || element.tagName.toLowerCase();
  }
  function extractElementLabel(element, root) {
    if (element.id) {
      const explicitLabel = root.querySelector(`label[for="${CSS.escape(element.id)}"]`);
      if (explicitLabel && explicitLabel.textContent && explicitLabel.textContent.trim()) {
        return cleanLabelText(explicitLabel.textContent);
      }
    }
    const enclosingLabel = element.closest("label");
    if (enclosingLabel && enclosingLabel.textContent) {
      const clone = enclosingLabel.cloneNode(true);
      const inputs = clone.querySelectorAll("input, select, textarea, button");
      inputs.forEach((i) => i.remove());
      if (clone.textContent && clone.textContent.trim()) {
        return cleanLabelText(clone.textContent);
      }
    }
    const labelledBy = element.getAttribute("aria-labelledby");
    if (labelledBy) {
      const ids = labelledBy.split(/\s+/);
      const parts = [];
      for (const id of ids) {
        const ref = root.querySelector(`#${CSS.escape(id)}`);
        if (ref && ref.textContent) {
          parts.push(ref.textContent.trim());
        }
      }
      if (parts.length > 0) {
        return cleanLabelText(parts.join(" "));
      }
    }
    const ariaLabel = element.getAttribute("aria-label");
    if (ariaLabel && ariaLabel.trim()) {
      return cleanLabelText(ariaLabel);
    }
    let parent = element.parentElement;
    for (let depth = 0; depth < 3 && parent && parent !== root && parent !== document.body; depth++) {
      const siblingInputs = parent.querySelectorAll('input:not([type="hidden"]), textarea, select');
      if (siblingInputs.length <= 2) {
        const header = parent.querySelector('label, [class*="label"], [class*="title"], [class*="header"]');
        if (header && header !== element && !header.contains(element) && header.textContent && header.textContent.trim()) {
          return cleanLabelText(header.textContent);
        }
      }
      parent = parent.parentElement;
    }
    const prevSibling = element.previousElementSibling;
    if (prevSibling && prevSibling.textContent && prevSibling.textContent.trim()) {
      if (["LABEL", "LEGEND", "H3", "H4", "H5", "P", "SPAN", "DIV"].includes(prevSibling.tagName)) {
        return cleanLabelText(prevSibling.textContent);
      }
    }
    const placeholder = element.placeholder || element.getAttribute("title");
    if (placeholder && placeholder.trim()) {
      return cleanLabelText(placeholder);
    }
    const fieldset = element.closest("fieldset");
    if (fieldset) {
      const inputs = fieldset.querySelectorAll('input:not([type="hidden"]), textarea, select');
      if (inputs.length <= 1) {
        const legend = fieldset.querySelector("legend");
        if (legend && legend.textContent && legend.textContent.trim()) {
          return cleanLabelText(legend.textContent);
        }
      }
    }
    return "";
  }
  function extractGroupQuestionLabel(inputs, root) {
    if (inputs.length === 0) return "";
    const first = inputs[0];
    if (!first) return "";
    const fieldset = first.closest('fieldset, [role="radiogroup"], [role="group"]');
    if (fieldset) {
      const fieldsetInputs = Array.from(fieldset.querySelectorAll('input:not([type="hidden"]), textarea, select'));
      const isDedicatedGroup = fieldsetInputs.length <= inputs.length || fieldsetInputs.every((i) => i.name === first.name);
      if (isDedicatedGroup) {
        const legend = fieldset.querySelector("legend, .question-title, h3, h4");
        if (legend && legend.textContent && legend.textContent.trim()) {
          return cleanLabelText(legend.textContent);
        }
      }
    }
    let container = first.parentElement;
    while (container && container !== root && container !== document.body) {
      if (inputs.every((i) => container?.contains(i))) {
        break;
      }
      container = container.parentElement;
    }
    if (container) {
      const innerHeading = container.querySelector(
        'legend, .question-title, h3, h4, h5, [class*="title"]:not([class*="hint"]), [class*="question-text"], [class*="field-label"]'
      );
      if (innerHeading && innerHeading.textContent && innerHeading.textContent.trim() && !inputs.some((i) => innerHeading.contains(i))) {
        return cleanLabelText(innerHeading.textContent);
      }
      const prev = container.previousElementSibling;
      if (prev && ["LEGEND", "LABEL", "H3", "H4", "H5", "DIV"].includes(prev.tagName)) {
        if (prev.textContent && prev.textContent.trim()) {
          return cleanLabelText(prev.textContent);
        }
      }
      const parentPrev = container.parentElement?.previousElementSibling;
      if (parentPrev && ["LEGEND", "LABEL", "H3", "H4", "H5", "DIV"].includes(parentPrev.tagName)) {
        if (parentPrev.textContent && parentPrev.textContent.trim()) {
          return cleanLabelText(parentPrev.textContent);
        }
      }
      const header = container.parentElement?.querySelector(
        'legend, .question-title, h3, h4, h5, [class*="title"], [class*="label"]'
      );
      if (header && header.textContent && header.textContent.trim() && !inputs.some((i) => header.contains(i))) {
        return cleanLabelText(header.textContent);
      }
    }
    return cleanLabelText(first.getAttribute("name") || "");
  }
  function isElementRequired(element, labelText) {
    if (element.hasAttribute("required")) return true;
    if (element.getAttribute("aria-required") === "true") return true;
    if (/\b(?:required|\*)\b/i.test(labelText)) return true;
    return false;
  }
  function extractNativeSelectOptions(select) {
    const options = [];
    for (let i = 0; i < select.options.length; i++) {
      const opt = select.options[i];
      if (opt) {
        options.push({
          value: opt.value,
          label: opt.text.trim() || opt.value
        });
      }
    }
    return options;
  }
  function isSubmitElement(element) {
    const tag = element.tagName.toLowerCase();
    const type = (element.getAttribute("type") || "").toLowerCase();
    if (type === "submit") {
      return true;
    }
    if (tag === "button" || tag === "input" || tag === "a") {
      const text = element.textContent || element.value || "";
      const selector = generateElementSelector(element, element.ownerDocument);
      if (isSubmissionIntent(selector, text)) {
        return true;
      }
    }
    return false;
  }

  // src/content/adapters/form/workday-form-adapter.ts
  var WorkdayFormAdapter = class {
    id = "workday";
    name = "Workday Application Wizard";
    priority = 40;
    matches(url, doc) {
      const host = url.hostname.toLowerCase();
      if (host.includes("myworkdayjobs.com") || host.includes("workday.com")) {
        return true;
      }
      return Boolean(
        doc.querySelector(
          '[data-automation-id*="workday"], [data-automation-id="workdayApplication"], [data-automation-id="compositeHeader"], [data-automation-id="pageHeader"]'
        )
      );
    }
    detectAuthBarrier(doc) {
      const isSignIn = Boolean(
        doc.querySelector(
          '[data-automation-id="signInPage"], [data-automation-id="createAccountPage"], form[data-automation-id="signInForm"]'
        )
      );
      const hasPasswordField = Boolean(
        doc.querySelector('input[type="password"], input[data-automation-id="password"]')
      );
      const hasJobFields = Boolean(
        doc.querySelector(
          '[data-automation-id*="legalName"], [data-automation-id*="addressSection"], [data-automation-id*="workHistory"], [data-automation-id="workdayApplication"]'
        )
      );
      if (isSignIn || hasPasswordField && !hasJobFields) {
        const signInBtn = doc.querySelector(
          'button[data-automation-id="signInSubmitButton"], button[data-automation-id="createAccountSubmitButton"], button[type="submit"]'
        );
        return {
          isBlocked: true,
          barrierType: isSignIn ? "login" : "login",
          message: "Workday requires signing in or creating an account before continuing with this application.",
          signInButtonSelector: signInBtn ? generateElementSelector(signInBtn, doc) : void 0
        };
      }
      return null;
    }
    detectWizardState(doc) {
      const stepItems = Array.from(
        doc.querySelectorAll(
          '[data-automation-id^="step-"], [data-automation-id*="stepItem"], li[data-automation-id*="step"], [data-automation-id="progressBar"] li'
        )
      );
      const headerText = doc.querySelector('[data-automation-id="compositeHeader"], [data-automation-id="pageHeader"]')?.textContent || "";
      const stepRegex = /step\s+(\d+)\s+of\s+(\d+)/i;
      const match = headerText.match(stepRegex);
      let currentStep = 1;
      let totalSteps = 1;
      let stepName;
      if (match && match[1] && match[2]) {
        currentStep = parseInt(match[1], 10);
        totalSteps = parseInt(match[2], 10);
        const namePart = headerText.split(/[-:–]/);
        if (namePart.length > 1 && namePart[1]) {
          stepName = namePart[1].trim();
        }
      } else if (stepItems.length > 0) {
        totalSteps = stepItems.length;
        stepItems.forEach((item, idx) => {
          if (item.getAttribute("aria-current") === "step" || item.classList.contains("active") || item.getAttribute("data-automation-id")?.includes("current")) {
            currentStep = idx + 1;
            stepName = item.textContent?.trim() || void 0;
          }
        });
      } else {
        return null;
      }
      const isFinalStep = currentStep === totalSteps || (stepName ? /review|submit/i.test(stepName) : false);
      let nextStepButtonSelector;
      if (!isFinalStep) {
        const nextBtn = doc.querySelector(
          'button[data-automation-id="bottom-navigation-next-button"], button[data-automation-id="nextButton"], button[data-automation-id="saveAndContinueButton"]'
        );
        if (nextBtn) {
          nextStepButtonSelector = generateElementSelector(nextBtn, doc);
        }
      }
      return {
        isMultiStep: true,
        currentStepIndex: currentStep,
        totalSteps,
        stepName,
        stepNames: stepItems.map((s) => s.textContent?.trim() || "").filter(Boolean),
        nextStepButtonSelector,
        isFinalStep
      };
    }
    detectValidationErrors(doc) {
      const errors = [];
      const errorElements = Array.from(
        doc.querySelectorAll(
          '[data-automation-id="errorMessage"], [data-automation-id="formError"], div.wd-error, [data-automation-id="errorBanner"]'
        )
      );
      for (const el of errorElements) {
        const msg = el.textContent?.trim();
        if (msg) {
          errors.push({
            fieldSelector: generateElementSelector(el, doc),
            message: msg
          });
        }
      }
      return errors;
    }
    crawlForm(doc, container) {
      const root = container || doc.querySelector('[data-automation-id="workdayApplication"]') || doc.querySelector('[data-automation-id="pageHeader"]')?.parentElement || doc.querySelector("main, form") || doc.body;
      const wizardState = this.detectWizardState(doc);
      const authBarrier = this.detectAuthBarrier(doc);
      const validationErrors = this.detectValidationErrors(doc);
      let submitButtonSelector;
      const isFinal = wizardState ? wizardState.isFinalStep : true;
      if (isFinal) {
        const submitBtn = root.querySelector(
          'button[data-automation-id="submitButton"], button[data-automation-id="bottom-navigation-submit-button"], button[type="submit"]'
        );
        if (submitBtn && isSubmitElement(submitBtn)) {
          submitButtonSelector = generateElementSelector(submitBtn, root);
        }
      }
      const fields = [];
      const radioInputs = Array.from(root.querySelectorAll('input[type="radio"]'));
      const radioGroups = /* @__PURE__ */ new Map();
      for (const radio of radioInputs) {
        const name = radio.name || radio.getAttribute("data-automation-id") || "unnamed_radio";
        const group = radioGroups.get(name) || [];
        group.push(radio);
        radioGroups.set(name, group);
      }
      for (const [name, radios] of radioGroups.entries()) {
        const firstRadio = radios[0];
        if (!firstRadio) continue;
        const label = extractGroupQuestionLabel(radios, root) || extractElementLabel(firstRadio, root);
        const required = radios.some((r) => isElementRequired(r, label));
        const selector = `input[type="radio"][name="${CSS.escape(firstRadio.name || name)}"]`;
        const options = radios.map((r) => {
          const optLabel = extractElementLabel(r, root) || r.value;
          return { value: r.value, label: optLabel };
        });
        const rawAttrs = {
          tag: "input",
          type: "radio",
          name,
          id: firstRadio.id,
          label,
          dataAutomationId: firstRadio.getAttribute("data-automation-id") || void 0
        };
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType: "radio",
          label: label || name,
          name,
          isRequired: required,
          options,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath
        });
      }
      const standardInputs = root.querySelectorAll(
        'input:not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="image"]), textarea, select'
      );
      for (const el of Array.from(standardInputs)) {
        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute("type") || "").toLowerCase();
        const name = el.getAttribute("name") || void 0;
        const id = el.id || void 0;
        const dataAutomationId = el.getAttribute("data-automation-id") || void 0;
        const label = extractElementLabel(el, root);
        const placeholder = el.placeholder || void 0;
        const required = isElementRequired(el, label);
        const selector = generateElementSelector(el, root);
        let fieldType = "text";
        let options;
        if (tag === "textarea") {
          fieldType = "textarea";
        } else if (tag === "select") {
          fieldType = "select";
          options = Array.from(el.options).map((opt) => ({
            value: opt.value,
            label: opt.text.trim() || opt.value
          }));
        } else if (type === "checkbox") {
          fieldType = "checkbox";
        } else if (type === "file") {
          fieldType = "file_upload";
        } else if (type === "email") {
          fieldType = "email";
        } else if (type === "tel") {
          fieldType = "tel";
        } else if (type === "number") {
          fieldType = "number";
        } else if (type === "date") {
          fieldType = "date";
        }
        const rawAttrs = {
          tag,
          type,
          name,
          id,
          label,
          placeholder,
          dataAutomationId
        };
        const isHoneypot = isHoneypotField(rawAttrs);
        if (type === "hidden" && !isHoneypot) continue;
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType,
          label: label || placeholder || dataAutomationId || name || id || "Input Field",
          placeholder,
          name,
          isRequired: required,
          options,
          currentValue: el.value || void 0,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath,
          isHoneypotSuspect: isHoneypot
        });
      }
      const customDropdowns = root.querySelectorAll(
        'button[data-automation-id="searchBox"], button[data-automation-id="promptOption"], div[data-automation-id="multiselectInputContainer"], [data-automation-id*="dropdown"]'
      );
      for (const dropdown of Array.from(customDropdowns)) {
        const dataAutomationId = dropdown.getAttribute("data-automation-id") || "";
        const selector = generateElementSelector(dropdown, root);
        if (fields.some((f) => f.selector === selector)) continue;
        const label = extractElementLabel(dropdown, root);
        const required = isElementRequired(dropdown, label);
        const rawAttrs = {
          tag: "button",
          type: "button",
          id: dropdown.id,
          label,
          dataAutomationId
        };
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType: "select",
          label: label || dataAutomationId || "Workday Selection Field",
          isRequired: required,
          currentValue: dropdown.textContent?.trim() || void 0,
          confidenceScore: Math.max(classification.confidence, 0.85),
          inferredMappingKey: classification.inferredProfilePath
        });
      }
      if (fields.length === 0 && !authBarrier && !submitButtonSelector && !wizardState) {
        return null;
      }
      return {
        id: `workday_form_${Date.now()}`,
        url: doc.location ? doc.location.href : "",
        detectedAts: this.id,
        fields,
        submitButtonSelector,
        isMultiStep: wizardState?.isMultiStep || false,
        currentStepIndex: wizardState?.currentStepIndex,
        totalSteps: wizardState?.totalSteps,
        authBarrier: authBarrier || void 0,
        stepProgression: wizardState || void 0,
        validationErrors: validationErrors.length > 0 ? validationErrors : void 0,
        inspectedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
  };

  // src/content/adapters/form/greenhouse-form-adapter.ts
  var GreenhouseFormAdapter = class {
    id = "greenhouse";
    name = "Greenhouse Application Form";
    priority = 30;
    matches(url, doc) {
      const host = url.hostname.toLowerCase();
      const search = url.search.toLowerCase();
      if (host.includes("greenhouse.io") || search.includes("gh_jid")) {
        return true;
      }
      return Boolean(
        doc.querySelector("#grnhse_app, form#application_form, [data-greenhouse], #main_fields, #eeo_questions")
      );
    }
    detectAuthBarrier(_doc) {
      return null;
    }
    detectWizardState(doc) {
      const stepIndicators = Array.from(doc.querySelectorAll(".step-item, .wizard-step, .nav-step"));
      if (stepIndicators.length > 1) {
        let currentStep = 1;
        stepIndicators.forEach((s, i) => {
          if (s.classList.contains("active") || s.classList.contains("current")) {
            currentStep = i + 1;
          }
        });
        const nextBtn = doc.querySelector("button.btn-next, .next-step-btn");
        return {
          isMultiStep: true,
          currentStepIndex: currentStep,
          totalSteps: stepIndicators.length,
          nextStepButtonSelector: nextBtn ? generateElementSelector(nextBtn, doc) : void 0,
          isFinalStep: currentStep === stepIndicators.length
        };
      }
      return null;
    }
    detectValidationErrors(doc) {
      const errors = [];
      const errorContainers = Array.from(
        doc.querySelectorAll('.field-error, .error-message, [aria-invalid="true"], .invalid-feedback')
      );
      for (const el of errorContainers) {
        const msg = el.textContent?.trim();
        if (msg) {
          errors.push({
            fieldSelector: generateElementSelector(el, doc),
            message: msg
          });
        }
      }
      return errors;
    }
    crawlForm(doc, container) {
      const root = container || doc.querySelector("#grnhse_app, form#application_form, #main_fields") || doc.body;
      const fields = [];
      const validationErrors = this.detectValidationErrors(doc);
      const wizardState = this.detectWizardState(doc);
      let submitButtonSelector;
      const submitBtn = root.querySelector(
        'input#submit_app, button#submit_app, input[type="submit"], [data-qa="submit-button"]'
      );
      if (submitBtn && isSubmitElement(submitBtn)) {
        submitButtonSelector = generateElementSelector(submitBtn, root);
      }
      const radioInputs = Array.from(root.querySelectorAll('input[type="radio"]'));
      const radioGroups = /* @__PURE__ */ new Map();
      for (const radio of radioInputs) {
        const name = radio.name || "unnamed_radio";
        const group = radioGroups.get(name) || [];
        group.push(radio);
        radioGroups.set(name, group);
      }
      for (const [name, radios] of radioGroups.entries()) {
        const firstRadio = radios[0];
        if (!firstRadio) continue;
        const label = extractGroupQuestionLabel(radios, root) || extractElementLabel(firstRadio, root);
        const required = radios.some((r) => isElementRequired(r, label));
        const selector = `input[type="radio"][name="${CSS.escape(firstRadio.name || name)}"]`;
        const options = radios.map((r) => {
          const optLabel = extractElementLabel(r, root) || r.value;
          return { value: r.value, label: optLabel };
        });
        const rawAttrs = {
          tag: "input",
          type: "radio",
          name,
          id: firstRadio.id,
          label
        };
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType: "radio",
          label: label || name,
          name,
          isRequired: required,
          options,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath
        });
      }
      const interactiveElements = root.querySelectorAll(
        'input:not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="image"]), textarea, select'
      );
      for (const el of Array.from(interactiveElements)) {
        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute("type") || "").toLowerCase();
        const name = el.getAttribute("name") || void 0;
        const id = el.id || void 0;
        const label = extractElementLabel(el, root);
        const placeholder = el.placeholder || void 0;
        const required = isElementRequired(el, label);
        const selector = generateElementSelector(el, root);
        let fieldType = "text";
        let options;
        if (tag === "textarea") {
          fieldType = "textarea";
        } else if (tag === "select") {
          fieldType = "select";
          options = extractNativeSelectOptions(el);
        } else if (type === "checkbox") {
          fieldType = "checkbox";
        } else if (type === "file") {
          fieldType = "file_upload";
        } else if (type === "email") {
          fieldType = "email";
        } else if (type === "tel") {
          fieldType = "tel";
        }
        const isEeoField = Boolean(el.closest("#eeo_questions, #eeo_fields, .eeo-section"));
        const rawAttrs = {
          tag,
          type,
          name,
          id,
          label,
          placeholder
        };
        const isHoneypot = isHoneypotField(rawAttrs);
        if (type === "hidden" && !isHoneypot) continue;
        let classification = classifyFormField(rawAttrs);
        if (isEeoField && (!classification.inferredProfilePath || classification.confidence < 0.7)) {
          const lowerLabel = (label || name || "").toLowerCase();
          if (lowerLabel.includes("gender") || lowerLabel.includes("sex")) {
            classification = {
              canonicalKey: "eeo_gender",
              confidence: 0.95,
              inferredProfilePath: "identity.eeo.gender",
              rationale: "Greenhouse EEO container gender field"
            };
          } else if (lowerLabel.includes("race") || lowerLabel.includes("ethnicity")) {
            classification = {
              canonicalKey: "eeo_race",
              confidence: 0.95,
              inferredProfilePath: "identity.eeo.race",
              rationale: "Greenhouse EEO container race field"
            };
          } else if (lowerLabel.includes("veteran")) {
            classification = {
              canonicalKey: "eeo_veteran",
              confidence: 0.95,
              inferredProfilePath: "identity.eeo.veteranStatus",
              rationale: "Greenhouse EEO container veteran field"
            };
          } else if (lowerLabel.includes("disability")) {
            classification = {
              canonicalKey: "eeo_disability",
              confidence: 0.95,
              inferredProfilePath: "identity.eeo.disabilityStatus",
              rationale: "Greenhouse EEO container disability field"
            };
          }
        }
        fields.push({
          id: createFieldId(),
          selector,
          fieldType,
          label: label || placeholder || name || id || "Input Field",
          placeholder,
          name,
          isRequired: required,
          options,
          currentValue: el.value || void 0,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath,
          isHoneypotSuspect: isHoneypot
        });
      }
      if (fields.length === 0) {
        return null;
      }
      return {
        id: root.id || `greenhouse_form_${Date.now()}`,
        url: doc.location ? doc.location.href : "",
        detectedAts: this.id,
        fields,
        submitButtonSelector,
        isMultiStep: wizardState?.isMultiStep || false,
        currentStepIndex: wizardState?.currentStepIndex,
        totalSteps: wizardState?.totalSteps,
        stepProgression: wizardState || void 0,
        validationErrors: validationErrors.length > 0 ? validationErrors : void 0,
        inspectedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
  };

  // src/content/adapters/form/lever-form-adapter.ts
  var LeverFormAdapter = class {
    id = "lever";
    name = "Lever Application Form";
    priority = 30;
    matches(url, doc) {
      const host = url.hostname.toLowerCase();
      if (host.includes("jobs.lever.co") || host.includes("lever.co")) {
        return true;
      }
      return Boolean(
        doc.querySelector('.lever-form, form#application-form, [data-qa="lever-application"], .application-page')
      );
    }
    detectAuthBarrier(_doc) {
      return null;
    }
    detectWizardState(_doc) {
      return null;
    }
    detectValidationErrors(doc) {
      const errors = [];
      const errorContainers = Array.from(
        doc.querySelectorAll(".application-error, .error-message, .invalid")
      );
      for (const el of errorContainers) {
        const msg = el.textContent?.trim();
        if (msg) {
          errors.push({
            fieldSelector: generateElementSelector(el, doc),
            message: msg
          });
        }
      }
      return errors;
    }
    crawlForm(doc, container) {
      const root = container || doc.querySelector('.lever-form, form#application-form, [data-qa="lever-application"]') || doc.body;
      const fields = [];
      const validationErrors = this.detectValidationErrors(doc);
      let submitButtonSelector;
      const submitBtn = root.querySelector(
        'button#btn-submit, button.postings-btn-submit, [data-qa="btn-submit"], input[type="submit"]'
      );
      if (submitBtn && isSubmitElement(submitBtn)) {
        submitButtonSelector = generateElementSelector(submitBtn, root);
      }
      const radioInputs = Array.from(root.querySelectorAll('input[type="radio"]'));
      const radioGroups = /* @__PURE__ */ new Map();
      for (const radio of radioInputs) {
        const name = radio.name || "unnamed_lever_radio";
        const group = radioGroups.get(name) || [];
        group.push(radio);
        radioGroups.set(name, group);
      }
      for (const [name, radios] of radioGroups.entries()) {
        const firstRadio = radios[0];
        if (!firstRadio) continue;
        const label = extractGroupQuestionLabel(radios, root) || extractElementLabel(firstRadio, root);
        const required = radios.some((r) => isElementRequired(r, label));
        const selector = `input[type="radio"][name="${CSS.escape(firstRadio.name || name)}"]`;
        const options = radios.map((r) => {
          const optLabel = extractElementLabel(r, root) || r.value;
          return { value: r.value, label: optLabel };
        });
        const rawAttrs = {
          tag: "input",
          type: "radio",
          name,
          id: firstRadio.id,
          label
        };
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType: "radio",
          label: label || name,
          name,
          isRequired: required,
          options,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath
        });
      }
      const interactiveElements = root.querySelectorAll(
        'input:not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="image"]), textarea, select'
      );
      for (const el of Array.from(interactiveElements)) {
        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute("type") || "").toLowerCase();
        const name = el.getAttribute("name") || void 0;
        const id = el.id || void 0;
        let label = extractElementLabel(el, root);
        const placeholder = el.placeholder || void 0;
        const required = isElementRequired(el, label);
        const selector = generateElementSelector(el, root);
        let fieldType = "text";
        let options;
        if (tag === "textarea") {
          fieldType = "textarea";
        } else if (tag === "select") {
          fieldType = "select";
          options = extractNativeSelectOptions(el);
        } else if (type === "checkbox") {
          fieldType = "checkbox";
        } else if (type === "file") {
          fieldType = "file_upload";
        } else if (type === "email") {
          fieldType = "email";
        } else if (type === "tel") {
          fieldType = "tel";
        }
        const questionSection = el.closest(".application-question, .application-additional");
        if (questionSection && !label) {
          const qTitle = questionSection.querySelector(".text, .application-label, h4");
          if (qTitle?.textContent?.trim()) {
            label = qTitle.textContent.trim();
          }
        }
        const rawAttrs = {
          tag,
          type,
          name,
          id,
          label,
          placeholder
        };
        const isHoneypot = isHoneypotField(rawAttrs);
        if (type === "hidden" && !isHoneypot) continue;
        let classification = classifyFormField(rawAttrs);
        if (name && name.startsWith("urls[")) {
          const linkType = name.slice(5, -1).toLowerCase();
          if (linkType === "linkedin") {
            classification = {
              canonicalKey: "linkedin_url",
              confidence: 0.98,
              inferredProfilePath: "links.linkedin",
              rationale: "Lever explicit LinkedIn input name"
            };
          } else if (linkType === "github") {
            classification = {
              canonicalKey: "github_url",
              confidence: 0.98,
              inferredProfilePath: "links.github",
              rationale: "Lever explicit GitHub input name"
            };
          } else if (linkType === "portfolio" || linkType === "other") {
            classification = {
              canonicalKey: "portfolio_url",
              confidence: 0.98,
              inferredProfilePath: "links.portfolio",
              rationale: "Lever explicit portfolio input name"
            };
          }
        }
        fields.push({
          id: createFieldId(),
          selector,
          fieldType,
          label: label || placeholder || name || id || "Input Field",
          placeholder,
          name,
          isRequired: required,
          options,
          currentValue: el.value || void 0,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath,
          isHoneypotSuspect: isHoneypot
        });
      }
      if (fields.length === 0) {
        return null;
      }
      return {
        id: root.id || `lever_form_${Date.now()}`,
        url: doc.location ? doc.location.href : "",
        detectedAts: this.id,
        fields,
        submitButtonSelector,
        isMultiStep: false,
        validationErrors: validationErrors.length > 0 ? validationErrors : void 0,
        inspectedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
  };

  // src/content/adapters/form/ashby-form-adapter.ts
  var AshbyFormAdapter = class {
    id = "ashby";
    name = "Ashby Application Form";
    priority = 30;
    matches(url, doc) {
      const host = url.hostname.toLowerCase();
      if (host.includes("ashbyhq.com") || host.includes("jobs.ashbyhq.com")) {
        return true;
      }
      return Boolean(
        doc.querySelector(
          '[data-ashby], #ashby-application-form, .ashby-application-form, [data-testid*="ashby"], div[class*="_ashbyContainer"]'
        )
      );
    }
    detectAuthBarrier(_doc) {
      return null;
    }
    detectWizardState(doc) {
      const stepIndicators = Array.from(
        doc.querySelectorAll('[role="progressbar"], .ashby-step, div[class*="_stepIndicator"]')
      );
      if (stepIndicators.length > 1) {
        let currentStep = 1;
        stepIndicators.forEach((s, i) => {
          if (s.getAttribute("aria-current") === "step" || s.classList.contains("active")) {
            currentStep = i + 1;
          }
        });
        const nextBtn = doc.querySelector('button[data-testid*="next"], button.ashby-next-button');
        return {
          isMultiStep: true,
          currentStepIndex: currentStep,
          totalSteps: stepIndicators.length,
          nextStepButtonSelector: nextBtn ? generateElementSelector(nextBtn, doc) : void 0,
          isFinalStep: currentStep === stepIndicators.length
        };
      }
      return null;
    }
    detectValidationErrors(doc) {
      const errors = [];
      const errorContainers = Array.from(
        doc.querySelectorAll(
          '[aria-invalid="true"], [data-invalid="true"], .ashby-form-field-error, div[class*="_errorMessage"]'
        )
      );
      for (const el of errorContainers) {
        const msg = el.textContent?.trim() || el.getAttribute("data-error-message");
        if (msg) {
          errors.push({
            fieldSelector: generateElementSelector(el, doc),
            message: msg
          });
        }
      }
      return errors;
    }
    crawlForm(doc, container) {
      const root = container || doc.querySelector(
        '#ashby-application-form, .ashby-application-form, [data-testid="application-form"], form'
      ) || doc.body;
      const fields = [];
      const validationErrors = this.detectValidationErrors(doc);
      const wizardState = this.detectWizardState(doc);
      let submitButtonSelector;
      const submitBtn = root.querySelector(
        'button[data-testid="submit-application-button"], button[type="submit"], button.ashby-submit'
      );
      if (submitBtn && isSubmitElement(submitBtn)) {
        submitButtonSelector = generateElementSelector(submitBtn, root);
      }
      const radioInputs = Array.from(root.querySelectorAll('input[type="radio"]'));
      const radioGroups = /* @__PURE__ */ new Map();
      for (const radio of radioInputs) {
        const name = radio.name || "unnamed_ashby_radio";
        const group = radioGroups.get(name) || [];
        group.push(radio);
        radioGroups.set(name, group);
      }
      for (const [name, radios] of radioGroups.entries()) {
        const firstRadio = radios[0];
        if (!firstRadio) continue;
        const label = extractGroupQuestionLabel(radios, root) || extractElementLabel(firstRadio, root);
        const required = radios.some((r) => isElementRequired(r, label));
        const selector = `input[type="radio"][name="${CSS.escape(firstRadio.name || name)}"]`;
        const options = radios.map((r) => {
          const optLabel = extractElementLabel(r, root) || r.value;
          return { value: r.value, label: optLabel };
        });
        const rawAttrs = {
          tag: "input",
          type: "radio",
          name,
          id: firstRadio.id,
          label
        };
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType: "radio",
          label: label || name,
          name,
          isRequired: required,
          options,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath
        });
      }
      const interactiveElements = root.querySelectorAll(
        'input:not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="image"]), textarea, select, [role="combobox"]'
      );
      for (const el of Array.from(interactiveElements)) {
        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute("type") || "").toLowerCase();
        const name = el.getAttribute("name") || void 0;
        const id = el.id || void 0;
        const label = extractElementLabel(el, root);
        const placeholder = el.placeholder || void 0;
        const required = isElementRequired(el, label);
        const selector = generateElementSelector(el, root);
        let fieldType = "text";
        let options;
        if (tag === "textarea") {
          fieldType = "textarea";
        } else if (tag === "select") {
          fieldType = "select";
          options = extractNativeSelectOptions(el);
        } else if (el.getAttribute("role") === "combobox") {
          fieldType = "select";
          const listboxId = el.getAttribute("aria-controls");
          if (listboxId) {
            const listbox = doc.getElementById(listboxId);
            if (listbox) {
              options = Array.from(listbox.querySelectorAll('[role="option"]')).map((opt) => ({
                value: opt.getAttribute("data-value") || opt.textContent?.trim() || "",
                label: opt.textContent?.trim() || ""
              }));
            }
          }
        } else if (type === "checkbox") {
          fieldType = "checkbox";
        } else if (type === "file") {
          fieldType = "file_upload";
        } else if (type === "email") {
          fieldType = "email";
        } else if (type === "tel") {
          fieldType = "tel";
        }
        const rawAttrs = {
          tag,
          type,
          name,
          id,
          label,
          placeholder
        };
        const isHoneypot = isHoneypotField(rawAttrs);
        if (type === "hidden" && !isHoneypot) continue;
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType,
          label: label || placeholder || name || id || "Input Field",
          placeholder,
          name,
          isRequired: required,
          options,
          currentValue: el.value || void 0,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath,
          isHoneypotSuspect: isHoneypot
        });
      }
      if (fields.length === 0) {
        return null;
      }
      return {
        id: root.id || `ashby_form_${Date.now()}`,
        url: doc.location ? doc.location.href : "",
        detectedAts: this.id,
        fields,
        submitButtonSelector,
        isMultiStep: wizardState?.isMultiStep || false,
        currentStepIndex: wizardState?.currentStepIndex,
        totalSteps: wizardState?.totalSteps,
        stepProgression: wizardState || void 0,
        validationErrors: validationErrors.length > 0 ? validationErrors : void 0,
        inspectedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
  };

  // src/content/adapters/form/generic-form-adapter.ts
  var GenericFormAdapter = class {
    id = "generic";
    name = "Standard Web Application Form";
    priority = 10;
    matches(_url, _doc) {
      return true;
    }
    detectAuthBarrier(doc) {
      const hasPassword = Boolean(doc.querySelector('input[type="password"]'));
      const hasJobFields = Boolean(
        doc.querySelector(
          'input[name*="resume"], input[name*="cv"], textarea, input[name*="experience"], input[name*="education"]'
        )
      );
      if (hasPassword && !hasJobFields) {
        const signInBtn = doc.querySelector('button[type="submit"], input[type="submit"]');
        return {
          isBlocked: true,
          barrierType: "login",
          message: "This application requires signing in to an existing account before proceeding.",
          signInButtonSelector: signInBtn ? generateElementSelector(signInBtn, doc) : void 0
        };
      }
      return null;
    }
    detectWizardState(doc) {
      const stepIndicators = Array.from(
        doc.querySelectorAll(
          'ol.steps li, ul.wizard-steps li, [role="progressbar"], .step-item, .progress-step'
        )
      );
      if (stepIndicators.length > 1) {
        let currentStep = 1;
        stepIndicators.forEach((s, i) => {
          if (s.classList.contains("active") || s.classList.contains("current") || s.getAttribute("aria-current") === "step") {
            currentStep = i + 1;
          }
        });
        const nextBtn = doc.querySelector(
          'button.btn-next, button.next-step, input[value*="Next" i], input[value*="Continue" i]'
        );
        return {
          isMultiStep: true,
          currentStepIndex: currentStep,
          totalSteps: stepIndicators.length,
          nextStepButtonSelector: nextBtn ? generateElementSelector(nextBtn, doc) : void 0,
          isFinalStep: currentStep === stepIndicators.length
        };
      }
      return null;
    }
    detectValidationErrors(doc) {
      const errors = [];
      const errorContainers = Array.from(
        doc.querySelectorAll(
          '[aria-invalid="true"], .invalid-feedback, .error-message, .field-error, .text-danger'
        )
      );
      for (const el of errorContainers) {
        const msg = el.textContent?.trim();
        if (msg) {
          errors.push({
            fieldSelector: generateElementSelector(el, doc),
            message: msg
          });
        }
      }
      return errors;
    }
    crawlForm(doc, container) {
      const root = container || doc.querySelector(
        'form#application, form.application, [data-qa="job-application"], main form, form'
      ) || doc.body;
      const fields = [];
      const validationErrors = this.detectValidationErrors(doc);
      const wizardState = this.detectWizardState(doc);
      const authBarrier = this.detectAuthBarrier(doc);
      let submitButtonSelector;
      const buttons = root.querySelectorAll('button, input[type="submit"], a.btn-submit');
      for (const btn of Array.from(buttons)) {
        if (isSubmitElement(btn)) {
          submitButtonSelector = generateElementSelector(btn, root);
          break;
        }
      }
      const radioInputs = Array.from(root.querySelectorAll('input[type="radio"]'));
      const radioGroups = /* @__PURE__ */ new Map();
      for (const radio of radioInputs) {
        const name = radio.name || "unnamed_radio_group";
        const group = radioGroups.get(name) || [];
        group.push(radio);
        radioGroups.set(name, group);
      }
      for (const [name, radios] of radioGroups.entries()) {
        const firstRadio = radios[0];
        if (!firstRadio) continue;
        const label = extractGroupQuestionLabel(radios, root) || extractElementLabel(firstRadio, root);
        const required = radios.some((r) => isElementRequired(r, label));
        const selector = `input[type="radio"][name="${CSS.escape(name)}"]`;
        const options = radios.map((r) => {
          const optLabel = extractElementLabel(r, root) || r.value;
          return { value: r.value, label: optLabel };
        });
        const rawAttrs = {
          tag: "input",
          type: "radio",
          name,
          id: firstRadio.id,
          label
        };
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType: "radio",
          label: label || name,
          name,
          isRequired: required,
          options,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath
        });
      }
      const interactiveElements = root.querySelectorAll(
        'input:not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="image"]), textarea, select, [role="combobox"]'
      );
      for (const el of Array.from(interactiveElements)) {
        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute("type") || "").toLowerCase();
        const name = el.getAttribute("name") || void 0;
        const id = el.id || void 0;
        const label = extractElementLabel(el, root);
        const placeholder = el.placeholder || void 0;
        const required = isElementRequired(el, label);
        const selector = generateElementSelector(el, root);
        let fieldType = "text";
        let options;
        if (tag === "textarea") {
          fieldType = "textarea";
        } else if (tag === "select") {
          fieldType = "select";
          options = extractNativeSelectOptions(el);
        } else if (el.getAttribute("role") === "combobox") {
          fieldType = "select";
        } else if (type === "checkbox") {
          fieldType = "checkbox";
        } else if (type === "file") {
          fieldType = "file_upload";
        } else if (type === "email") {
          fieldType = "email";
        } else if (type === "tel") {
          fieldType = "tel";
        } else if (type === "number") {
          fieldType = "number";
        } else if (type === "date") {
          fieldType = "date";
        }
        const rawAttrs = {
          tag,
          type,
          name,
          id,
          label,
          placeholder
        };
        const isHoneypot = isHoneypotField(rawAttrs);
        if (type === "hidden" && !isHoneypot) continue;
        const classification = classifyFormField(rawAttrs);
        fields.push({
          id: createFieldId(),
          selector,
          fieldType,
          label: label || placeholder || name || id || "Input Field",
          placeholder,
          name,
          isRequired: required,
          options,
          currentValue: el.value || void 0,
          confidenceScore: classification.confidence,
          inferredMappingKey: classification.inferredProfilePath,
          isHoneypotSuspect: isHoneypot
        });
      }
      if (fields.length === 0 && !authBarrier) {
        return null;
      }
      return {
        id: root instanceof HTMLElement && root.id ? root.id : `generic_form_${Date.now()}`,
        url: doc.location ? doc.location.href : "",
        detectedAts: this.id,
        fields,
        submitButtonSelector,
        isMultiStep: wizardState?.isMultiStep || false,
        currentStepIndex: wizardState?.currentStepIndex,
        totalSteps: wizardState?.totalSteps,
        authBarrier: authBarrier || void 0,
        stepProgression: wizardState || void 0,
        validationErrors: validationErrors.length > 0 ? validationErrors : void 0,
        inspectedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
  };

  // src/content/adapters/form/index.ts
  var FORM_ADAPTERS = [
    new WorkdayFormAdapter(),
    new GreenhouseFormAdapter(),
    new LeverFormAdapter(),
    new AshbyFormAdapter(),
    new GenericFormAdapter()
  ].sort((a, b) => b.priority - a.priority);
  function findMatchingFormAdapter(url, doc) {
    for (const adapter of FORM_ADAPTERS) {
      if (adapter.matches(url, doc)) {
        return adapter;
      }
    }
    return new GenericFormAdapter();
  }
  function inspectPageWithAtsAdapters(doc) {
    if (!doc.location) {
      throw new Error("Cannot inspect application form without a document location.");
    }
    const url = new URL(doc.location.href);
    const adapter = findMatchingFormAdapter(url, doc);
    const form = adapter.crawlForm(doc);
    if (form) {
      return [form];
    }
    if (adapter.id !== "generic") {
      const fallback = new GenericFormAdapter();
      const fallbackForm = fallback.crawlForm(doc);
      if (fallbackForm) {
        return [fallbackForm];
      }
    }
    return [];
  }

  // src/content/form-crawler.ts
  function detectAtsPlatform(doc, url) {
    const normUrl = url.toLowerCase();
    if (normUrl.includes("greenhouse.io") || normUrl.includes("gh_jid")) {
      return "greenhouse";
    }
    if (normUrl.includes("jobs.lever.co") || normUrl.includes("lever.co")) {
      return "lever";
    }
    if (normUrl.includes("myworkdayjobs.com") || normUrl.includes("workday.com")) {
      return "workday";
    }
    if (normUrl.includes("ashbyhq.com") || normUrl.includes("ashby")) {
      return "ashby";
    }
    if (normUrl.includes("smartrecruiters.com")) {
      return "smartrecruiters";
    }
    if (doc.querySelector("#grnhse_app, form#application_form, [data-greenhouse]")) {
      return "greenhouse";
    }
    if (doc.querySelector('.lever-form, [data-qa="lever-application"], .postings-btn-wrapper')) {
      return "lever";
    }
    if (doc.querySelector('[data-automation-id*="workday"], [data-automation-id="workdayApplication"]')) {
      return "workday";
    }
    if (doc.querySelector("[data-ashby], #ashby-application-form, .ashby-application-form")) {
      return "ashby";
    }
    if (doc.querySelector("[data-smartrecruiters], .smartr-form")) {
      return "smartrecruiters";
    }
    return "generic";
  }
  function crawlFormContainer(container, doc) {
    const atsPlatform = detectAtsPlatform(doc, doc.location ? doc.location.href : "");
    const fields = [];
    let submitButtonSelector;
    const buttons = container.querySelectorAll('button, input[type="submit"], a.btn-submit, [role="button"]');
    for (const btn of Array.from(buttons)) {
      if (isSubmitElement(btn)) {
        submitButtonSelector = generateElementSelector(btn, container);
        break;
      }
    }
    const radioInputs = Array.from(container.querySelectorAll('input[type="radio"]'));
    const radioGroups = /* @__PURE__ */ new Map();
    for (const radio of radioInputs) {
      const name = radio.name || "unnamed_radio_group";
      const group = radioGroups.get(name) || [];
      group.push(radio);
      radioGroups.set(name, group);
    }
    for (const [name, radios] of radioGroups.entries()) {
      const firstRadio = radios[0];
      if (!firstRadio) continue;
      const label = extractGroupQuestionLabel(radios, container) || extractElementLabel(firstRadio, container);
      const required = radios.some((r) => isElementRequired(r, label));
      const selector = `input[type="radio"][name="${CSS.escape(name)}"]`;
      const options = radios.map((r) => {
        const optLabel = extractElementLabel(r, container) || r.value;
        return {
          value: r.value,
          label: optLabel
        };
      });
      const rawAttrs = {
        tag: "input",
        type: "radio",
        name,
        id: firstRadio.id,
        label
      };
      const classification = classifyFormField(rawAttrs);
      fields.push({
        id: createFieldId(),
        selector,
        fieldType: "radio",
        label: label || name,
        name,
        isRequired: required,
        options,
        confidenceScore: classification.confidence,
        inferredMappingKey: classification.inferredProfilePath
      });
    }
    const interactiveElements = container.querySelectorAll(
      'input:not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="image"]), textarea, select, [role="combobox"]'
    );
    for (const el of Array.from(interactiveElements)) {
      const tag = el.tagName.toLowerCase();
      const type = (el.getAttribute("type") || "").toLowerCase();
      const name = el.getAttribute("name") || void 0;
      const id = el.id || void 0;
      const label = extractElementLabel(el, container);
      const placeholder = el.placeholder || void 0;
      const autocomplete = el.getAttribute("autocomplete") || void 0;
      const ariaLabel = el.getAttribute("aria-label") || void 0;
      const required = isElementRequired(el, label);
      const selector = generateElementSelector(el, container);
      let fieldType = "text";
      let options;
      if (tag === "textarea") {
        fieldType = "textarea";
      } else if (tag === "select") {
        fieldType = "select";
        options = extractNativeSelectOptions(el);
      } else if (el.getAttribute("role") === "combobox") {
        fieldType = "select";
      } else if (type === "checkbox") {
        fieldType = "checkbox";
      } else if (type === "file") {
        fieldType = "file_upload";
      } else if (type === "email") {
        fieldType = "email";
      } else if (type === "tel") {
        fieldType = "tel";
      } else if (type === "number") {
        fieldType = "number";
      } else if (type === "date") {
        fieldType = "date";
      } else if (type === "hidden") {
        fieldType = "hidden";
      }
      const rawAttrs = {
        tag,
        type,
        name,
        id,
        label,
        placeholder,
        autocomplete,
        ariaLabel
      };
      const isSuspectHoneypot = isHoneypotField(rawAttrs);
      if (fieldType === "hidden" && !isSuspectHoneypot) {
        continue;
      }
      const classification = classifyFormField(rawAttrs);
      fields.push({
        id: createFieldId(),
        selector,
        fieldType,
        label: label || placeholder || name || id || "Input Field",
        placeholder,
        name,
        isRequired: required,
        options,
        currentValue: el.value || void 0,
        confidenceScore: classification.confidence,
        inferredMappingKey: classification.inferredProfilePath,
        isHoneypotSuspect: isSuspectHoneypot
      });
    }
    const formAction = container instanceof HTMLFormElement ? container.action : void 0;
    const formMethod = container instanceof HTMLFormElement ? container.method : void 0;
    if (!doc.location) {
      throw new Error("Cannot crawl application form without a document location.");
    }
    const parsedUrl = new URL(doc.location.href);
    const adapter = findMatchingFormAdapter(parsedUrl, doc);
    const authBarrier = adapter.detectAuthBarrier ? adapter.detectAuthBarrier(doc) : null;
    const wizardState = adapter.detectWizardState ? adapter.detectWizardState(doc) : null;
    const validationErrors = adapter.detectValidationErrors ? adapter.detectValidationErrors(doc) : [];
    return {
      id: container.id || `form_${Date.now()}`,
      url: doc.location ? doc.location.href : "",
      detectedAts: atsPlatform,
      formAction,
      formMethod,
      fields,
      submitButtonSelector,
      isMultiStep: wizardState?.isMultiStep || false,
      currentStepIndex: wizardState?.currentStepIndex,
      totalSteps: wizardState?.totalSteps,
      authBarrier: authBarrier || void 0,
      stepProgression: wizardState || void 0,
      validationErrors: validationErrors.length > 0 ? validationErrors : void 0,
      inspectedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  function inspectPageForms(doc) {
    const adapterForms = inspectPageWithAtsAdapters(doc);
    if (adapterForms.length > 0) {
      return adapterForms;
    }
    const forms = [];
    const formElements = Array.from(doc.querySelectorAll("form"));
    if (formElements.length > 0) {
      for (const formEl of formElements) {
        const inputs = formEl.querySelectorAll("input, select, textarea");
        if (inputs.length >= 2) {
          forms.push(crawlFormContainer(formEl, doc));
        }
      }
    }
    if (forms.length === 0) {
      const appContainer = doc.querySelector(
        '#application, [data-qa="job-application"], .application-form, main, [role="main"]'
      );
      if (appContainer) {
        const inputs = appContainer.querySelectorAll("input, select, textarea");
        if (inputs.length >= 2) {
          forms.push(crawlFormContainer(appContainer, doc));
        }
      }
    }
    if (forms.length === 0) {
      const bodyInputs = doc.body.querySelectorAll("input, select, textarea");
      if (bodyInputs.length >= 2) {
        forms.push(crawlFormContainer(doc.body, doc));
      }
    }
    return forms;
  }

  // src/content/pacing-engine.ts
  var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function calculateRandomDelay(min, max) {
    const low = Math.min(min, max);
    const high = Math.max(min, max);
    return Math.floor(Math.random() * (high - low + 1)) + low;
  }
  function calculateElementClickCoordinates(element, addJitter = true) {
    let clientX = 100;
    let clientY = 100;
    if (typeof element.getBoundingClientRect === "function") {
      const rect = element.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        clientX = rect.left + rect.width / 2;
        clientY = rect.top + rect.height / 2;
        if (addJitter) {
          const maxJitterX = Math.min(rect.width * 0.25, 8);
          const maxJitterY = Math.min(rect.height * 0.25, 6);
          const jitterX = (Math.random() - 0.5) * 2 * maxJitterX;
          const jitterY = (Math.random() - 0.5) * 2 * maxJitterY;
          clientX += jitterX;
          clientY += jitterY;
        }
      }
    }
    return {
      clientX: Math.round(clientX),
      clientY: Math.round(clientY),
      screenX: Math.round(clientX + 20),
      screenY: Math.round(clientY + 80)
    };
  }
  function dispatchRealisticPointerSequence(element, coords) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: element.ownerDocument?.defaultView || window,
      clientX: coords.clientX,
      clientY: coords.clientY,
      screenX: coords.screenX,
      screenY: coords.screenY,
      button: 0,
      buttons: 1
    };
    element.dispatchEvent(new PointerEvent("pointerover", init));
    element.dispatchEvent(new MouseEvent("mouseover", init));
    element.dispatchEvent(new PointerEvent("pointerdown", init));
    element.dispatchEvent(new MouseEvent("mousedown", init));
    element.focus();
    element.dispatchEvent(new MouseEvent("click", init));
    element.dispatchEvent(new MouseEvent("mouseup", { ...init, buttons: 0 }));
    element.dispatchEvent(new PointerEvent("pointerup", { ...init, buttons: 0 }));
  }
  async function typeTextProgressively(element, text, options) {
    const pacingMode = options?.pacingMode || "natural";
    if (pacingMode === "instant") {
      element.focus();
      setNativeInputValue(element, text);
      element.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          composed: true,
          data: text,
          inputType: "insertText"
        })
      );
      element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      element.blur();
      return;
    }
    const coords = calculateElementClickCoordinates(element, options?.addCoordinateJitter !== false);
    dispatchRealisticPointerSequence(element, coords);
    if (pacingMode === "fast") {
      await sleep(options?.pacingDelayMs ?? 15);
      setNativeInputValue(element, text);
      element.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          composed: true,
          data: text,
          inputType: "insertText"
        })
      );
      element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      element.blur();
      return;
    }
    const minDelay = options?.minKeystrokeDelayMs ?? 20;
    const maxDelay = options?.maxKeystrokeDelayMs ?? 65;
    let currentText = "";
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      currentText += char;
      element.dispatchEvent(
        new KeyboardEvent("keydown", {
          key: char,
          code: `Key${char.toUpperCase()}`,
          bubbles: true,
          composed: true
        })
      );
      setNativeInputValue(element, currentText);
      element.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          composed: true,
          data: char,
          inputType: "insertText"
        })
      );
      element.dispatchEvent(
        new KeyboardEvent("keyup", {
          key: char,
          code: `Key${char.toUpperCase()}`,
          bubbles: true,
          composed: true
        })
      );
      const delay = calculateRandomDelay(minDelay, maxDelay);
      await sleep(delay);
    }
    element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    element.blur();
  }

  // src/content/action-interpreter.ts
  var sleep2 = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function setNativeInputValue(element, value) {
    const proto = element instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
    if (descriptor && descriptor.set) {
      descriptor.set.call(element, value);
    } else {
      element.value = value;
    }
  }
  function setNativeCheckboxChecked(element, checked) {
    const descriptor = Object.getOwnPropertyDescriptor(
      HTMLInputElement.prototype,
      "checked"
    );
    if (descriptor && descriptor.set) {
      descriptor.set.call(element, checked);
    } else {
      element.checked = checked;
    }
  }
  function simulateTextInput(element, text) {
    element.dispatchEvent(new MouseEvent("pointerdown", { bubbles: true, composed: true }));
    element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, composed: true }));
    element.focus();
    setNativeInputValue(element, text);
    element.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        composed: true,
        data: text,
        inputType: "insertText"
      })
    );
    element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    element.blur();
  }
  function simulateSelectOption(selectElement, optionValue) {
    selectElement.focus();
    const descriptor = Object.getOwnPropertyDescriptor(
      HTMLSelectElement.prototype,
      "value"
    );
    if (descriptor && descriptor.set) {
      descriptor.set.call(selectElement, optionValue);
    } else {
      selectElement.value = optionValue;
    }
    for (const option of Array.from(selectElement.options)) {
      option.selected = option.value === optionValue;
    }
    selectElement.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    selectElement.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    selectElement.blur();
  }
  function simulateCustomComboboxSelect(element, optionValue) {
    element.focus();
    if (element instanceof HTMLInputElement) {
      simulateTextInput(element, optionValue);
    } else {
      element.dispatchEvent(new MouseEvent("pointerdown", { bubbles: true, composed: true }));
      element.dispatchEvent(new MouseEvent("click", { bubbles: true, composed: true }));
    }
    const root = element.ownerDocument || document;
    const options = Array.from(
      root.querySelectorAll(
        '[role="option"], .select-option, [data-automation-id="promptOption"], li[data-value]'
      )
    );
    const matched = options.find((opt) => {
      const text = (opt.textContent || "").trim().toLowerCase();
      const val = (opt.getAttribute("data-value") || "").toLowerCase();
      const target = optionValue.trim().toLowerCase();
      return text === target || val === target || text.includes(target);
    });
    if (matched && !isSubmitElement(matched)) {
      matched.dispatchEvent(new MouseEvent("pointerdown", { bubbles: true, composed: true }));
      matched.dispatchEvent(new MouseEvent("click", { bubbles: true, composed: true }));
    } else {
      element.setAttribute("data-value", optionValue);
      if (!(element instanceof HTMLInputElement)) {
        element.textContent = optionValue;
      }
    }
    element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    element.blur();
  }
  function simulateClick(element, options) {
    if (isSubmitElement(element)) {
      throw new Error("Autonomous submission blocked: clicking submit controls is forbidden.");
    }
    const coords = calculateElementClickCoordinates(element, options?.addCoordinateJitter !== false);
    dispatchRealisticPointerSequence(element, coords);
  }
  function simulateCheckbox(checkbox, checked) {
    checkbox.focus();
    if (checkbox.checked !== checked) {
      checkbox.click();
    }
    setNativeCheckboxChecked(checkbox, checked);
    checkbox.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    checkbox.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    checkbox.blur();
  }
  function simulateFileUpload(fileInput, fileName) {
    fileInput.focus();
    const file = new File(["[Verified Candidate Document Attachment]"], fileName, {
      type: "application/pdf",
      lastModified: Date.now()
    });
    if (typeof DataTransfer !== "undefined") {
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      fileInput.files = dataTransfer.files;
    }
    fileInput.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    fileInput.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    fileInput.blur();
  }
  function applyVisualHighlight(element) {
    const previousOutline = element.style.outline;
    const previousOffset = element.style.outlineOffset;
    const previousTransition = element.style.transition;
    element.style.outline = "2px solid #10b981";
    element.style.outlineOffset = "2px";
    element.style.transition = "outline 0.2s ease-in-out";
    if (typeof element.scrollIntoView === "function") {
      try {
        element.scrollIntoView({ behavior: "smooth", block: "nearest" });
      } catch {
      }
    }
    return () => {
      element.style.outline = previousOutline;
      element.style.outlineOffset = previousOffset;
      element.style.transition = previousTransition;
    };
  }
  async function executeSingleAction(action, doc, options = {}) {
    const browserAction = action.action;
    const safety = validateBrowserActionSafety(browserAction);
    if (safety.isProhibited) {
      throw new Error(`Action prohibited by safety policy: ${safety.reason}`);
    }
    if (browserAction.actionType === "click" && isSubmissionIntent(browserAction.selector, browserAction.description)) {
      throw new Error("Autonomous submission blocked: clicking submit controls is forbidden.");
    }
    const element = doc.querySelector(browserAction.selector);
    if (!element) {
      throw new Error(`Target DOM element not found for selector: ${browserAction.selector}`);
    }
    if (isSubmitElement(element)) {
      throw new Error("Autonomous submission blocked: target is classified as a submit element.");
    }
    const cleanupHighlight = options.highlightElements !== false ? applyVisualHighlight(element) : () => {
    };
    try {
      switch (browserAction.actionType) {
        case "fill_text": {
          const input = element;
          if (options.pacingMode === "natural" && options.simulateKeystrokes !== false) {
            await typeTextProgressively(input, browserAction.value || "", options);
          } else {
            simulateTextInput(input, browserAction.value || "");
          }
          break;
        }
        case "select_option": {
          if (element instanceof HTMLSelectElement) {
            simulateSelectOption(element, browserAction.value || "");
          } else {
            simulateCustomComboboxSelect(element, browserAction.value || "");
          }
          break;
        }
        case "click": {
          simulateClick(element, options);
          break;
        }
        case "check":
        case "uncheck": {
          const checkbox = element;
          simulateCheckbox(checkbox, browserAction.actionType === "check");
          break;
        }
        case "upload_file": {
          const fileInput = element;
          simulateFileUpload(fileInput, browserAction.value || "resume.pdf");
          break;
        }
        case "scroll_into_view": {
          if (typeof element.scrollIntoView === "function") {
            element.scrollIntoView({ behavior: "smooth", block: "center" });
          }
          break;
        }
        case "wait_for_selector": {
          break;
        }
        default:
          throw new Error(`Unsupported browser action type: ${browserAction.actionType}`);
      }
    } finally {
      const delay = options.pacingDelayMs ?? 150;
      setTimeout(cleanupHighlight, Math.max(delay, 200));
    }
  }
  async function executeBrowserPlan(plan, doc, options = {}) {
    const startTime = Date.now();
    const pacingDelay = options.pacingDelayMs ?? 150;
    const executedActionIds = [];
    const failedActions = [];
    const approvedActions = plan.actions.filter((a) => a.userConfirmed);
    for (const action of approvedActions) {
      try {
        await executeSingleAction(action, doc, options);
        executedActionIds.push(action.id);
        if (pacingDelay > 0) {
          await sleep2(pacingDelay);
        }
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        failedActions.push({
          actionId: action.id,
          selector: action.action.selector,
          error: errorMsg
        });
      }
    }
    const durationMs = Date.now() - startTime;
    return {
      planId: plan.id,
      totalPlanned: approvedActions.length,
      executedCount: executedActionIds.length,
      failedCount: failedActions.length,
      haltedAtSubmissionGate: true,
      // Guarantees execution paused before final submission
      executedActionIds,
      failedActions,
      durationMs,
      completedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }

  // src/content/in-page-inspector.ts
  var STYLESHEET_ID = "applykit-inpage-styles";
  var CALLOUT_CLASS = "applykit-focus-callout";
  var PREVIEW_BADGE_CLASS = "applykit-preview-badge";
  var currentHighlight = null;
  function ensureStylesInjected(doc) {
    if (doc.getElementById(STYLESHEET_ID)) return;
    const style = doc.createElement("style");
    style.id = STYLESHEET_ID;
    style.textContent = `
    .${CALLOUT_CLASS} {
      position: absolute;
      z-index: 2147483647;
      background: #1e293b;
      color: #f8fafc;
      border: 1px solid #3b82f6;
      border-radius: 6px;
      padding: 4px 8px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 11px;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      pointer-events: none;
      transform: translateY(-100%);
      margin-top: -6px;
      white-space: nowrap;
      transition: opacity 0.2s ease;
    }
    .${PREVIEW_BADGE_CLASS} {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #10b981;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 10px;
      font-weight: 600;
      padding: 2px 6px;
      border-radius: 4px;
      margin-left: 6px;
      vertical-align: middle;
      pointer-events: none;
      z-index: 1000;
    }
  `;
    doc.head.appendChild(style);
  }
  function clearTargetHighlight(doc) {
    if (currentHighlight) {
      const { element, originalOutline, originalOutlineOffset, originalBoxShadow, originalTransition, calloutElement } = currentHighlight;
      element.style.outline = originalOutline;
      element.style.outlineOffset = originalOutlineOffset;
      element.style.boxShadow = originalBoxShadow;
      element.style.transition = originalTransition;
      if (calloutElement && calloutElement.parentElement) {
        calloutElement.remove();
      }
      currentHighlight = null;
    }
    const orphaned = doc.querySelectorAll(`.${CALLOUT_CLASS}`);
    orphaned.forEach((node) => node.remove());
  }
  function highlightTargetElement(doc, selector, label) {
    clearTargetHighlight(doc);
    const element = doc.querySelector(selector);
    if (!element) return false;
    ensureStylesInjected(doc);
    const originalOutline = element.style.outline;
    const originalOutlineOffset = element.style.outlineOffset;
    const originalBoxShadow = element.style.boxShadow;
    const originalTransition = element.style.transition;
    element.style.outline = "3px solid #3b82f6";
    element.style.outlineOffset = "3px";
    element.style.boxShadow = "0 0 14px rgba(59, 130, 246, 0.4)";
    element.style.transition = "outline 0.2s ease, box-shadow 0.2s ease";
    if (typeof element.scrollIntoView === "function") {
      try {
        element.scrollIntoView({ behavior: "smooth", block: "center" });
      } catch {
      }
    }
    let calloutElement;
    if (label && doc.body) {
      calloutElement = doc.createElement("div");
      calloutElement.className = CALLOUT_CLASS;
      calloutElement.textContent = `ApplyKit: ${label}`;
      if (typeof element.getBoundingClientRect === "function") {
        const rect = element.getBoundingClientRect();
        const scrollTop = window.scrollY || doc.documentElement.scrollTop || 0;
        const scrollLeft = window.scrollX || doc.documentElement.scrollLeft || 0;
        calloutElement.style.top = `${rect.top + scrollTop}px`;
        calloutElement.style.left = `${rect.left + scrollLeft}px`;
        doc.body.appendChild(calloutElement);
      }
    }
    currentHighlight = {
      element,
      originalOutline,
      originalOutlineOffset,
      originalBoxShadow,
      originalTransition,
      calloutElement
    };
    return true;
  }
  function renderInPageReviewBadges(doc, plan) {
    removeInPageReviewBadges(doc);
    ensureStylesInjected(doc);
    let mountedCount = 0;
    for (const action of plan.actions) {
      const element = doc.querySelector(action.action.selector);
      if (!element) continue;
      const badge = doc.createElement("span");
      badge.className = PREVIEW_BADGE_CLASS;
      badge.setAttribute("data-applykit-preview-id", action.id);
      badge.textContent = `&#10003; ${action.candidateValueUsed || action.action.description}`;
      if (element.parentElement) {
        element.parentElement.insertBefore(badge, element.nextSibling);
        mountedCount++;
      }
    }
    return mountedCount;
  }
  function removeInPageReviewBadges(doc) {
    const badges = doc.querySelectorAll(`.${PREVIEW_BADGE_CLASS}`);
    badges.forEach((node) => node.remove());
    const styleTag = doc.getElementById(STYLESHEET_ID);
    if (styleTag) {
      styleTag.remove();
    }
  }

  // src/content/index.ts
  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (!message || typeof message !== "object" || !("type" in message)) {
        return false;
      }
      const requestType = message.type;
      if (requestType === "PING") {
        const pong = {
          type: "PONG",
          timestamp: Date.now()
        };
        sendResponse(pong);
        return false;
      }
      if (requestType === "EXTRACT_JOB") {
        try {
          const data = extractPageData(document, window.location.href);
          const jobPosting = extractStructuredJob(document, window.location.href);
          const response = {
            type: "EXTRACT_JOB_RESULT",
            success: true,
            data,
            jobPosting
          };
          sendResponse(response);
        } catch (err) {
          const errorMsg = err instanceof Error ? err.message : String(err);
          const failureResponse = {
            type: "EXTRACT_JOB_RESULT",
            success: false,
            error: errorMsg
          };
          sendResponse(failureResponse);
        }
        return false;
      }
      if (requestType === "INSPECT_PAGE_FORMS") {
        try {
          const forms = inspectPageForms(document);
          const response = {
            type: "INSPECT_PAGE_FORMS_RESULT",
            success: true,
            forms: [...forms]
          };
          sendResponse(response);
        } catch (err) {
          const errorMsg = err instanceof Error ? err.message : String(err);
          const failureResponse = {
            type: "INSPECT_PAGE_FORMS_RESULT",
            success: false,
            forms: [],
            error: errorMsg
          };
          sendResponse(failureResponse);
        }
        return false;
      }
      if (requestType === "EXECUTE_CONTENT_PLAN") {
        const planReq = message;
        executeBrowserPlan(planReq.plan, document, planReq.options).then((report) => {
          const response = {
            type: "EXECUTE_CONTENT_PLAN_RESULT",
            success: true,
            report
          };
          sendResponse(response);
        }).catch((err) => {
          const errorMsg = err instanceof Error ? err.message : String(err);
          const failureResponse = {
            type: "EXECUTE_CONTENT_PLAN_RESULT",
            success: false,
            error: errorMsg
          };
          sendResponse(failureResponse);
        });
        return true;
      }
      if (requestType === "HIGHLIGHT_FORM_FIELD") {
        const payload = message;
        const success = highlightTargetElement(document, payload.selector, payload.label);
        const response = {
          type: "HIGHLIGHT_FORM_FIELD_RESULT",
          success
        };
        sendResponse(response);
        return false;
      }
      if (requestType === "CLEAR_FORM_FIELD_HIGHLIGHT") {
        clearTargetHighlight(document);
        const response = {
          type: "CLEAR_FORM_FIELD_HIGHLIGHT_RESULT",
          success: true
        };
        sendResponse(response);
        return false;
      }
      if (requestType === "TOGGLE_IN_PAGE_REVIEW_BADGES") {
        const payload = message;
        let count = 0;
        if (payload.enabled && payload.plan) {
          count = renderInPageReviewBadges(document, payload.plan);
        } else {
          removeInPageReviewBadges(document);
        }
        const response = {
          type: "TOGGLE_IN_PAGE_REVIEW_BADGES_RESULT",
          success: true,
          count
        };
        sendResponse(response);
        return false;
      }
      return false;
    });
  }
})();
